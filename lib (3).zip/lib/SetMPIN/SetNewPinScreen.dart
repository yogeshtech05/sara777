import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../Helper/Toast.dart'; // Assuming this is your popToast
import '../login/HomeScreen/HomeScreen.dart';
import '../ulits/ColorsR.dart';
import '../ulits/Constents.dart';

class SetNewPinScreen extends StatefulWidget {
  final String mobile;
  const SetNewPinScreen({super.key, required this.mobile});

  @override
  State<SetNewPinScreen> createState() => _SetNewPinScreenState();
}

class _SetNewPinScreenState extends State<SetNewPinScreen> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController pinController = TextEditingController();
  final storage = GetStorage();
  late final String fcmToken;

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fcmToken = storage.read('fcmToken') ?? '';
    log("FCM Token: $fcmToken");
  }

  @override
  void dispose() {
    passwordController.dispose();
    pinController.dispose();
    super.dispose();
  }

  Future<void> setNewPin() async {
    final mobile = widget.mobile;
    final password = passwordController.text.trim();
    final newPin = pinController.text.trim();

    if (password.isEmpty) {
      popToast(
        "Please enter your password",
        4,
        Colors.white,
        ColorsR.appColorRed,
      );
      return;
    }

    if (newPin.isEmpty || newPin.length != 4) {
      popToast(
        "Please enter a 4-digit PIN",
        4,
        Colors.white,
        ColorsR.appColorRed,
      );
      return;
    }

    setState(() => isLoading = true);

    final body = {
      "mobileNo": int.tryParse(
        mobile,
      ), // Ensure mobile number is parsed as int if API expects it
      "password": password,
      "security_pin": int.tryParse(newPin),
      "fcmToken": fcmToken,
    };

    try {
      final response = await http.post(
        Uri.parse('${Constant.apiEndpoint}reset-mpin'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      print("📤 Request Body: $body");
      print("📥 Response: ${response.body}");

      final json = jsonDecode(response.body);
      final msg = json['msg'] ?? "Something went wrong";
      final status = json['status'] ?? false;

      if (status == true) {
        final info = json['info'];
        final registerId = info['registerId'];
        final accessToken = info['accessToken'];

        // ✅ Save to GetStorage
        storage.write('user_mpin', newPin);
        storage.write('registerId', registerId);
        storage.write('accessToken', accessToken);

        popToast(msg, 2, Colors.white, Colors.green);

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const HomeScreen()),
          (route) => false, // Remove all previous routes
        );
      } else {
        popToast(msg, 4, Colors.white, ColorsR.appColorRed);
      }
    } catch (e) {
      String friendlyMsg = "Something went wrong. Please try again.";
      if (e.toString().contains('SocketException')) {
        friendlyMsg = "No internet connection. Please check and try again.";
      }
      popToast("❌ $friendlyMsg", 4, Colors.white, ColorsR.appColorRed);
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              Row(
                children: [
                  Container(width: 10, height: 50, color: Colors.orange),
                  const SizedBox(width: 8),
                  Text(
                    'SET NEW\nPIN',
                    style: GoogleFonts.poppins(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 60),
              const Text("Enter Password"),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                height: 50,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextField(
                  cursorColor: Colors.orange,
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    counterText: "",
                    hintText: "Enter your password",
                  ),
                ),
              ),
              const SizedBox(height: 25),
              const Text("Enter New Security PIN"),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                height: 50,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextField(
                  cursorColor: Colors.orange,
                  controller: pinController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    counterText: "",
                    hintText: "Enter 4 digit PIN",
                  ),
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                ),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  onPressed: isLoading ? null : setNewPin,
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text(
                          "SET PIN",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            letterSpacing: 1.0,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}