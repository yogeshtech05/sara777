import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:developer'; // Added for logging
import 'package:new_sara/login/HomeScreen/HomeScreen.dart'; // Import HomeScreen

import '../../../ulits/ColorsR.dart'; // Ensure this import path is correct
import '../../Helper/Toast.dart'; // Ensure this import path is correct
import '../ulits/Constents.dart'; // Ensure this import path is correct

class SetPinScreen extends StatefulWidget {
  const SetPinScreen({super.key});

  @override
  State<SetPinScreen> createState() => _SetPinScreenState();
}

class _SetPinScreenState extends State<SetPinScreen> {
  final TextEditingController mpinController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final storage = GetStorage();
  bool isLoading = false;

  void _onSetPinPressed() async {
    final pin = mpinController.text.trim();

    if (pin.isEmpty || pin.length != 4 || !RegExp(r'^\d{4}$').hasMatch(pin)) {
      popToast(
        "Please enter a valid 4-digit PIN",
        4,
        Colors.white,
        ColorsR.appColorRed,
      );
      return;
    }

    final mobile = storage.read('mobile');
    final username = storage.read('username');
    final password = storage.read('password');

    if (mobile == null || username == null || password == null) {
      popToast("Missing registration data", 4, Colors.white, ColorsR.appColorRed);
      return;
    }

    setState(() => isLoading = true);

    try {
      storage.write('user_mpin', pin);

      final Uri url = Uri.parse('${Constant.apiEndpoint}user-register');
      final Map<String, dynamic> requestBody = {
        "fullName": username,
        "mobileNo": int.tryParse(mobile.toString()) ?? mobile,
        "password": password,
        "password_confirmation": password,
        "security_pin": int.tryParse(pin),
      };

      final response = await http.post(
        url,
        headers: {
          'deviceId': 'qwert',
          'deviceName': 'sm2233',
          'accessStatus': '1',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody),
      );

      log("📥 Register response: ${response.body}");
      final json = jsonDecode(response.body);

      if (json['status'] == true) {
         if (json.containsKey('info') && json['info'] != null) {
           final info = json['info'];
           storage.write('accessToken', info['accessToken']);
           storage.write('registerId', info['registerId']);
         }
         
         popToast(json['msg'] ?? "Registration Successful", 2, Colors.white, Colors.green);
         
         Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const HomeScreen()),
          (route) => false,
        );
      } else {
        popToast(json['msg'] ?? "Registration failed", 4, Colors.white, ColorsR.appColorRed);
      }

    } catch (e) {
      log("❌ Register error: $e");
      String friendlyMsg = "Something went wrong. Please try again.";
      if (e.toString().contains('SocketException')) {
        friendlyMsg = "No internet connection. Please check and try again.";
      }
      popToast(
        friendlyMsg,
        4,
        Colors.white,
        ColorsR.appColorRed,
      );
    } finally {
      setState(() => isLoading = false);
    }
  }


  @override
  void dispose() {
    mpinController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(width: 6, height: 40, color: Colors.orange),
                    const SizedBox(width: 8),
                    Text(
                      "SET YOUR\nPIN",
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: Colors.black87,
                        height: 1.2,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 40),
                Center(
                  child: Image.asset(
                    'assets/images/set_mpin_avatar.png',
                    height: 200,
                  ),
                ),
                const SizedBox(height: 40),
                const Text(
                  "Enter New Security PIN",
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: mpinController,
                  keyboardType: TextInputType.number,
                  obscureText: true,
                  maxLength: 4,
                  cursorColor: Colors.orange,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey.shade200,
                    counterText: '',
                    hintText: "Enter 4 digit PIN",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                // const SizedBox(height: 24),
                // const Text(
                //   "Enter Password",
                //   style: TextStyle(
                //     fontSize: 14,
                //     color: Colors.black87,
                //     fontWeight: FontWeight.w500,
                //   ),
                // ),
                // const SizedBox(height: 8),
                // TextField(
                //   controller: passwordController,
                //   keyboardType: TextInputType.text,
                //   obscureText: true,
                //   cursorColor: Colors.orange,
                //   decoration: InputDecoration(
                //     filled: true,
                //     fillColor: Colors.grey.shade200,
                //     counterText: '',
                //     hintText: "Enter your password",
                //     border: OutlineInputBorder(
                //       borderRadius: BorderRadius.circular(8),
                //       borderSide: BorderSide.none,
                //     ),
                //   ),
                // ),
                 const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: isLoading ? null : _onSetPinPressed,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors
                          .white, // Changed from Colors.black to white for better contrast with amber background
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    child: isLoading
                        ? const CircularProgressIndicator(color: Colors.black)
                        : const Text(
                            "SET PIN",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              letterSpacing: 1,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}