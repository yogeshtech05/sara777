import 'package:flutter/material.dart';

void closeBidDialogue({
  required BuildContext context,
  required String gameName,
  required String openResultTime,
  required String openBidLastTime,
  required String closeResultTime,
  required String closeBidLastTime,
}) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) {
      return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        insetPadding: EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          width: double.maxFinite,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Orange cross icon with sparkles
              Stack(
                alignment: Alignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: Color(0xFFFD8340),
                    radius: 35,
                    child: Icon(Icons.close, size: 45, color: Colors.white),
                  ),
                ],
              ),
              SizedBox(height: 15),

              // Game name
              Text(
                gameName.toUpperCase(),
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                  color: Color(0xff1c2134),
                  letterSpacing: 0.5,
                ),
              ),
              SizedBox(height: 8),

              // Closed for Today text
              Text(
                "Closed for Today",
                style: TextStyle(
                  color: Color(0xffA7292e),
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 8),

              // Timings Table
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFFD4A04f), width: 1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    _buildTimeRow("Open Bid Last time", openBidLastTime, isFirst: true),
                //    Divider(height: 1, thickness: 2, color: Color(0xFFDAA520)),
                    _buildTimeRow("Open Result Time", openResultTime),
                 //   Divider(height: 1, thickness: 1, color: Color(0xFFDAA520)),
                    _buildTimeRow("Close Bid Last Time", closeBidLastTime),
               //     Divider(height: 1, thickness: 2, color: Color(0xFFDAA520)),
                    _buildTimeRow("Close Result Time", closeResultTime, isLast: true),
                  ],
                ),
              ),
              SizedBox(height: 24),

              // OK Button
              SizedBox(
                width: 130,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFE8910C),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 0,
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    "OK",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

Widget _buildTimeRow(String label, String time, {bool isFirst = false, bool isLast = false}) {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 14, vertical: 7),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "$label :",
          style: TextStyle(
            color: Colors.black87,
            fontSize: 15,
            fontWeight: FontWeight.w500,
          ),
        ),
        Text(
          time.isNotEmpty ? time : "--:--",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black,
            fontSize: 15,
          ),
        ),
      ],
    ),
  );
}