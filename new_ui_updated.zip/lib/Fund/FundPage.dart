import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart' show Obx;
import 'package:new_sara/Fund/BankDetailsFragment.dart';

import '../Helper/TranslationHelper.dart';
import '../Helper/UserController.dart';
import 'AddFundScreen.dart';
import 'DepositHistoryPage.dart';
import 'WithdrawScreen.dart';
import 'WithdrawalHistoryPage.dart';
import '../HomeScreen/HomeScreen.dart';

class FundsScreen extends StatefulWidget {
  final void Function(String title)? onItemTap;

  FundsScreen({super.key, this.onItemTap});

  @override
  State<FundsScreen> createState() => _FundsScreenState();
}

class _FundsScreenState extends State<FundsScreen> {
  TranslationHelper translationHelper = TranslationHelper();
  final UserController userController = Get.put(UserController());

  final List<_FundOption> fundOptions = [
    _FundOption("Add Fund", "assets/images/add_fund.png"),
    _FundOption("Withdraw Funds", "assets/images/withdrawl_fund.png"),
    _FundOption("Bank Details", "assets/images/add_bank_details.png"),
    _FundOption("Deposit History", "assets/images/fund_deposite_history.png"),
    _FundOption("Withdraw History", "assets/images/fund_withdraw_history.png"),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.transparent,
      body: Container(
        width: double.infinity,
        height: double.infinity,

        /// 🔥 FULL GRADIENT BACKGROUND
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFE8D1), Color(0xFFEFF8F0)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),

        child: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(35),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),

                  // ⭐ FIX: Container has ONE child → Column
                  child: Column(
                    children: [
                      // -------------------- TOP HEADER INSIDE WHITE AREA --------------------
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: () {
                                // Navigate to HomeScreen instead of popping
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(builder: (context) => HomeScreen()),
                                  (route) => false,
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: const Icon(
                                  Icons.arrow_back,
                                  color: Colors.black,
                                  size: 20,
                                ),
                              ),
                            ),

                            const Text(
                              'Funds',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),

                            // WALLET CAPSULE
                            Obx(
                                  () => userController.accountStatus.value
                                  ? Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF0B1223),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/images/ic_wallet.png",
                                      width: 20,
                                      height: 20,
                                      color: Colors.white,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      "₹${userController.walletBalance.value}",
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                                  : const SizedBox.shrink(),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 12),

                      // -------------------- LIST AREA --------------------
                      Expanded(
                        child: ListView.builder(
                          padding: const EdgeInsets.only(bottom: 10),
                          itemCount: fundOptions.length,
                          itemBuilder: (context, index) {
                            final item = fundOptions[index];

                            return InkWell(
                              onTap: () {
                                switch (item.title) {
                                  case "Add Fund":
                                    Navigator.push(context,
                                        MaterialPageRoute(builder: (_) => AddFundScreen()));
                                    break;
                                  case "Withdraw Funds":
                                    Navigator.push(context,
                                        MaterialPageRoute(builder: (_) => WithdrawScreen()));
                                    break;
                                  case "Bank Details":
                                    Navigator.push(context,
                                        MaterialPageRoute(builder: (_) => BankDetailsFragment()));
                                    break;
                                  case "Deposit History":
                                    Navigator.push(context,
                                        MaterialPageRoute(builder: (_) => DepositHistoryPage()));
                                    break;
                                  case "Withdraw History":
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (_) => WithdrawalHistoryPage()));
                                    break;
                                }
                              },

                              // PREMIUM CARD
                              child: Container(
                                margin: const EdgeInsets.symmetric(
                                  vertical: 10,
                                  horizontal: 16,
                                ),
                                padding: const EdgeInsets.symmetric(
                                  vertical: 8,
                                  horizontal: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xffFCFCFC),
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(color: Colors.grey.shade300),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.08),
                                      blurRadius: 7,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),

                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: const BoxDecoration(
                                        color: Color(0xffFE8545),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Image.asset(
                                        item.assetIconPath,
                                        width: 28,
                                        height: 28,
                                        color: Colors.white,
                                      ),
                                    ),

                                    const SizedBox(width: 18),

                                    Expanded(
                                      child: Text(
                                        item.title,
                                        style: const TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),

                                    const Icon(Icons.arrow_forward_ios,
                                        size: 18, color: Colors.orange),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

class _FundOption {
  final String title;
  final String assetIconPath;

  _FundOption(this.title, this.assetIconPath);
}
