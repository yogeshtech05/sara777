import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

import '../../../../ulits/ColorsR.dart';
import '../../../Components/showAccountRecoveryDialog.dart';
import '../../../Helper/Toast.dart';
import '../ulits/Constents.dart';
import 'CreateAccountScreen.dart';

class EnterMobileScreen extends StatefulWidget {
  const EnterMobileScreen({super.key});

  @override
  State<EnterMobileScreen> createState() => _EnterMobileScreenState();
}

class _EnterMobileScreenState extends State<EnterMobileScreen> {
  final TextEditingController mobileController = TextEditingController();
  final storage = GetStorage();

  bool isLoading = false;

  /// ✅ VALIDATION FUNCTION
  String? validateMobile(String mobile) {
    if (mobile.isEmpty) return 'Mobile number is required';
    if (!RegExp(r'^[0-9]{10}$').hasMatch(mobile)) {
      return 'Enter a valid 10-digit mobile number';
    }
    return null;
  }

  /// ✅ API FUNCTION (Copied from your working screen)
  Future<void> _handleNextPressed() async {
    final mobile = mobileController.text.trim();
    final validation = validateMobile(mobile);

    if (validation != null) {
      popToast(validation, 4, Colors.white, ColorsR.appColorRed);
      return;
    }

    setState(() => isLoading = true);

    try {
      final response = await http
          .post(
            Uri.parse('${Constant.apiEndpoint}check-mobile'),
            headers: {
              'deviceId': 'qwert',
              'deviceName': 'sm2233',
              'accessStatus': '1',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({"mobileNo": int.tryParse(mobile)}),
          )
          .timeout(const Duration(seconds: 10));

      print("Raw Response: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final statusRaw = data['status'];
        final bool status = statusRaw.toString().toLowerCase().trim() == "true";

        storage.write('mobile', mobile);

        if (status) {
          /// Existing user → Show recovery dialog
          showAccountRecoveryDialog(context, mobile);
        } else {
          /// New user → Go to Create Account
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const CreateAccountScreen()),
          );
        }
      } else {
        popToast(
          "Server Error: ${response.statusCode}",
          4,
          Colors.white,
          ColorsR.appColorRed,
        );
      }
    } on TimeoutException {
      popToast(
        "Request timed out. Check internet.",
        4,
        Colors.white,
        ColorsR.appColorRed,
      );
    } catch (e) {
      popToast("Something went wrong.", 4, Colors.white, ColorsR.appColorRed);
      print("Exception: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFE7D1), Color(0xFFEFF8F0)],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 30),

              /// ⭐ TITLE
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  children: [
                    const Text(
                      "Welcome To ",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                      ),
                    ),
                    const Text(
                      "SARA",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      "777",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.orange.shade700,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 8),

              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  "India’s best Satta Matka Application\nWelcomes you !!!",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.black87,
                    height: 1.4,
                  ),
                ),
              ),

              const SizedBox(height: 25),

              /// MAIN WHITE CONTAINER
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 22,
                    vertical: 30,
                  ),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                  ),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Phone Number",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),

                      const SizedBox(height: 12),

                      /// ⭐ INPUT FIELD
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.grey, width: 1.2),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.phone_android,
                              color: Colors.orange.shade600,
                              size: 28,
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              "+91",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: TextField(
                                controller: mobileController,
                                keyboardType: TextInputType.phone,
                                maxLength: 10,
                                decoration: const InputDecoration(
                                  counterText: "",
                                  border: InputBorder.none,
                                  hintText: "Enter Phone Number",
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 40),

                      /// ⭐ NEXT BUTTON → API CALL
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onPressed: isLoading ? null : _handleNextPressed,
                          child: isLoading
                              ? const CircularProgressIndicator(
                                  color: Colors.white,
                                )
                              : const Text(
                                  "NEXT",
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                        ),
                      ),

                      const Spacer(),

                      /// FOOTER
                      Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.verified_user,
                              color: Colors.green.shade600,
                              size: 20,
                            ),
                            const SizedBox(width: 6),
                            const Text(
                              "Trusted by 1 Lakh Users",
                              style: TextStyle(fontSize: 14),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
