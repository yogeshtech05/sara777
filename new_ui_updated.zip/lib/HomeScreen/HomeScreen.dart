// File: lib/HomeScreen.dart
import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Bids/MyBidsPage.dart';
import '../ChartScreen/ChartScreen.dart';
import '../Helper/Toast.dart';
import '../Helper/UserController.dart';
import '../Login/LoginWithMpinScreen.dart';
import '../Navigation/FundsFragmentContainer.dart';
import '../Notice/WithdrawInfoScreen.dart';
import '../Notification/NotificationScreen.dart';
import '../Passbook/PassbookPage.dart';
import '../SetMPIN/SetNewPinScreen.dart';
import '../SettingsScreen/SettingsScreen.dart';
import '../Support/ChatSupport/ChatSupport.dart';
import '../Support/SupportPage.dart';
import '../Video/LanguageSelectionScreen.dart';
import '../components/AppName.dart';
import '../game/gameRates/GameRateScreen.dart';
import '../ulits/ColorsR.dart';
import '../ulits/Constents.dart';
import 'HomePage.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  late final UserController userController = Get.isRegistered<UserController>()
      ? Get.find<UserController>()
      : Get.put(UserController(), permanent: true);

  final GetStorage storage = GetStorage();
  int _selectedIndex = 2;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    log('HomeScreen sees UserController hash: ${userController.hashCode}');
    _bootstrapLoad();
    storage.write('isLoggedIn', true);
    userController.startLivePolling(interval: const Duration(seconds: 6));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    userController.stopLivePolling();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      userController.fetchAndUpdateUserDetails();
    }
  }

  Future<void> _bootstrapLoad() async {
    try {
      await userController.fetchAndUpdateUserDetails();
      await Future.wait([
        userController.fetchAndUpdateFeeSettings(),
        userController.fetchAndUpdateContactDetails(),
        userController.fetchPaymentDetails(),
      ]);
    } catch (e, st) {
      log('Warm-up error: $e', stackTrace: st);
    }
  }

  String _normalizePhone(String raw, {String defaultCountryCode = '91'}) {
    var p = raw.replaceAll(RegExp(r'[^0-9]'), '');
    p = p.replaceFirst(RegExp(r'^0+'), '');
    if (p.length == 10) p = '$defaultCountryCode$p';
    return p;
  }

  String? _getSupportNumber() {
    final w = userController.contactWhatsappNo.value.trim();
    if (w.isNotEmpty) return w;
    final c = userController.contactMobileNo.value.trim();
    if (c.isNotEmpty) return c;
    final s = (storage.read('whatsappNo') ?? '').toString().trim();
    if (s.isNotEmpty) return s;
    final u = userController.mobileNo.value.trim();
    if (u.isNotEmpty) return u;
    return null;
  }

  Future<void> launchWhatsAppChat({String? message}) async {
    try {
      final raw = _getSupportNumber();
      if (raw == null) {
        popToast("WhatsApp number not available", 4, Colors.white, ColorsR.appColorRed);
        log("❌ WhatsApp number missing (all sources empty)");
        return;
      }

      final phone = _normalizePhone(raw);
      final encoded = (message ?? '').trim().isEmpty ? '' : Uri.encodeComponent(message!.trim());

      final nativeUri = Uri.parse('whatsapp://send?phone=$phone${encoded.isNotEmpty ? '&text=$encoded' : ''}');
      if (await canLaunchUrl(nativeUri)) {
        final ok = await launchUrl(nativeUri, mode: LaunchMode.externalApplication);
        log(ok ? '✅ Launched WhatsApp (native): $nativeUri' : '❌ Failed (native)');
        if (ok) return;
      }

      final webUri = Uri.parse('https://wa.me/$phone${encoded.isNotEmpty ? '?text=$encoded' : ''}');
      if (await canLaunchUrl(webUri)) {
        final ok = await launchUrl(webUri, mode: LaunchMode.externalApplication);
        log(ok ? '✅ Launched WhatsApp (web): $webUri' : '❌ Failed (web)');
        if (ok) return;
      }

      popToast("Could not launch WhatsApp", 4, Colors.white, ColorsR.appColorRed);
    } catch (e, st) {
      log('❌ WhatsApp launch error: $e', stackTrace: st);
      popToast("Error launching WhatsApp", 4, Colors.white, ColorsR.appColorRed);
    }
  }

  final List<Widget> _screens = [
    BidScreen(),
    PassbookPage(),
    HomePage(),
    FundsFragmentContainer(),
    SupportPage(),
    WithdrawInfoScreen(),
    SettingsScreen(),
    GameRateScreen(),
    ChatScreen(),
  ];

  void _onItemTapped(int index) {
    if (index >= 0 && index < _screens.length) {
      setState(() => _selectedIndex = index);
    } else {
      log("Error: Attempted to select invalid index: $index");
    }
  }

  void _navigateToNewScreen(Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  void _navigateToDrawerScreenAndPush(Widget screen) {
    Navigator.pop(context);
    _navigateToNewScreen(screen);
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.transparent,
      elevation: 0,
      toolbarHeight: 82,
      title: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFE7D1),   // soft peach
              Color(0xFFEFF8F0),   // very light mint
            ],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),
        child: Row(
          children: [

            // 🔥 LEFT CAPSULE (MENU + LOGO)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
               // color: Colors.white,
                borderRadius: BorderRadius.circular(40),
                border: Border.all(color: Colors.black12),
              ),
              child: Row(
                children: [
                  // menu icon
                  Builder(
                    builder: (ctx) => GestureDetector(
                      onTap: () => Scaffold.of(ctx).openDrawer(),
                      child: Image.asset(
                        "assets/images/ic_menu.png",
                        width: 22,
                        height: 22,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),

                  // logo name (Sara777 / Mama567)
                  const AppName(), // your existing widget
                ],
              ),
            ),

            const Spacer(),

            // 🔥 WALLET CAPSULE (dark blue)
            Obx(() => userController.accountStatus.value
                ?
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF0B1223),
                borderRadius: BorderRadius.circular(40),
              ),
              child: Row(
                children: [
                  Image.asset(
                    "assets/images/ic_wallet.png",
                    width: 20,
                    height: 20,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "₹${userController.walletBalance.value}",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            )
                : const SizedBox.shrink()),

            const SizedBox(width: 12),

            // 🔔 NOTIFICATION CAPSULE
            Obx(() => userController.accountStatus.value
                ? Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                border: Border.all(color: Colors.black12),
               // color: Colors.white,
              ),
              child: IconButton(
                icon: Image.asset(
                  "assets/images/ic_notification.png",
                  width: 22,
                  height: 22,
                  color: Colors.black,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NoticeHistoryScreen()),
                  );
                },
              ),
            )
                : const SizedBox.shrink()),
          ],
        ),
      ),
    );
  }
  Widget _buildBodyHeader() {
    // Hide header when on Funds screen (index 3) or Bid screen (index 0)
    if (_selectedIndex == 3 || _selectedIndex == 0) {
      return const SizedBox.shrink();
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(

      ),
      child: Row(
        children: [

          // LEFT CAPSULE (menu + logo)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              border: Border.all(color: Colors.black12),
            ),
            child: Row(
              children: [
                Builder(
                  builder: (ctx) => GestureDetector(
                    onTap: () => Scaffold.of(ctx).openDrawer(),
                    child: Image.asset(
                      "assets/images/ic_menu.png",
                      width: 22,
                      height: 22,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const AppName(),  // Same as before
              ],
            ),
          ),

          const Spacer(),

          // WALLET
          Obx(() => userController.accountStatus.value
              ? Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF0B1223),
              borderRadius: BorderRadius.circular(40),
            ),
            child: Row(
              children: [
                Image.asset(
                  "assets/images/ic_wallet.png",
                  width: 20,
                  height: 20,
                  color: Colors.white,
                ),
                const SizedBox(width: 8),
                Text(
                  "₹${userController.walletBalance.value}",
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          )
              : const SizedBox.shrink()
          ),

          const SizedBox(width: 12),

          // NOTIFICATION
          Obx(() => userController.accountStatus.value
              ? Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              border: Border.all(color: Colors.black12),
            ),
            child: IconButton(
              icon: Image.asset(
                "assets/images/ic_notification.png",
                width: 20,
                height: 20,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NoticeHistoryScreen()),
                );
              },
            ),
          )
              : const SizedBox.shrink()
          ),
        ],
      ),
    );
  }

  Drawer _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.white,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              height: 110,
              // decoration: const BoxDecoration(
              //   gradient: LinearGradient(
              //     colors: [
              //       Color(0xFFFFE7D1),  // Soft Yellow-Orange
              //       Color(0xFFEFF8F0),  // Soft Off-White Mint
              //     ],
              //     begin: Alignment.centerLeft,
              //     end: Alignment.centerRight,
              //   ),
              // ),
             color: Colors.white,
              child: Row(
                children: [
                  CircleAvatar(radius: 32, backgroundColor: Colors.grey.shade300, child: const Icon(Icons.person, size: 34, color: Colors.black)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Obx(() => Text(userController.fullName.value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                      Obx(() => Text(userController.mobileNoEnc.value, style: const TextStyle(color: Colors.black54), overflow: TextOverflow.ellipsis)),
                    ]),
                  ),
                  IconButton(icon: const Icon(Icons.close, color: Colors.black), onPressed: () => Navigator.of(context).pop()),
                ],
              ),
            ),
            Expanded(
              child: Obx(
                    () => ListView(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), children: [
                  _buildDrawerItem("assets/images/home_nav.png", "Home", () {
                    Navigator.pop(context);
                    _onItemTapped(2);
                  }, true),
                  _buildDrawerItem("assets/images/bid_nav.png", "My Bids", () {
                    Navigator.pop(context);
                    _onItemTapped(0);
                  }, userController.accountStatus.value),
                  _buildDrawerItem("assets/images/mpin_nav.png", "M-PIN", () {
                    Navigator.pop(context);
                    _handleMpin();
                  }, userController.accountStatus.value),
                  _buildDrawerItem("assets/images/passbook.png", "Passbook", () => _navigateToDrawerScreenAndPush(const PassbookPage()), userController.accountStatus.value),
                  _buildDrawerItem("assets/images/funds_nav.png", "Funds", () {
                    Navigator.pop(context);
                    _onItemTapped(3);
                  }, userController.accountStatus.value),
                  _buildDrawerItem("assets/images/videos.png", "Videos", () => _navigateToDrawerScreenAndPush(const LanguageSelectionScreen()), userController.accountStatus.value),
                  _buildDrawerItem("assets/images/rate_stars.png", "Game Rates", () {
                    Navigator.pop(context);
                    _onItemTapped(7);
                  }, userController.accountStatus.value),
                  _buildDrawerItem("assets/images/charts.png", "Charts", () => _navigateToDrawerScreenAndPush(const ChartScreen()), userController.accountStatus.value),
                  _buildDrawerItem("assets/images/setting_nav.png", "Settings", () {
                    Navigator.pop(context);
                    _onItemTapped(6);
                  }, userController.accountStatus.value),
                  _buildDrawerItem("assets/images/share.png", "Share Application", () {
                    Navigator.pop(context);
                    Share.share("I'm loving Sara 777 App\n\nDownload App now\n\nFrom:-\nhttps://admin.sara777.app", subject: "Check out the Sara 777 App!");
                  }, userController.accountStatus.value),
                  _buildDrawerItem("assets/images/power.png", "Logout", () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginWithMpinScreen()));
                  }, true),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(String imagePath, String title, VoidCallback onTap, bool visible) {
    if (!visible) return const SizedBox.shrink();
    return Column(
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 8),
          leading: Image.asset(imagePath, width: 28, height: 28, fit: BoxFit.contain),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
          onTap: onTap,
        ),

        // 🔥 Divider added here
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Divider(
            thickness: 0.8,
            color: Colors.black12,
          ),
        ),
      ],
    );
  }


  void _handleMpin() async {
    final String mobile = userController.mobileNo.value;
    if (mobile.isEmpty) {
      log("Mobile number is not available.");
      popToast("Mobile number is not available", 4, Colors.white, ColorsR.appColorRed);
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => SetNewPinScreen(mobile: mobile)));
  }

  Widget _buildBottomAppBar() {
    return Obx(() {
      final accountStatus = userController.accountStatus.value;
      return SafeArea(
        child: Stack(alignment: Alignment.center, children: [
          Container(
            height: 72,
           // decoration: BoxDecoration(color: Colors.grey.shade100, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, -2))]),

            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFFFFE7D1),   // Soft Yellow-Orange (left)
                  Color(0xFFEFF8F0),   // Soft Off-White Mint (right)
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 8,
                  offset: Offset(0, -2),
                )
              ],
            ),



            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                _buildNavItem("assets/images/bid_nav.png", "My Bids", 0, visible: accountStatus),
                _buildNavItem("assets/images/passbook.png", "Passbook", 1, visible: accountStatus),
              ])),
              SizedBox(width: MediaQuery.of(context).size.width * 0.20),
              Expanded(child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                _buildNavItem("assets/images/funds.png", "Funds", 3, visible: accountStatus),
                _buildNavItem("assets/images/chat_icon.png", "Chat", 8, visible: accountStatus),
              ])),
            ]),
          ),
          Positioned(
            top: 0,
            child: GestureDetector(
              onTap: () => _onItemTapped(2),
              child: Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFFFA726), Color(0xFFFFC458)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0, 4))],
                  border: Border.all(color: Colors.orange.shade700, width: 2),
                ),
                child: const Icon(Icons.home, color: Colors.black, size: 32),
              ),
            ),
          ),
        ]),
      );
    });
  }

  Widget _buildNavItem(String iconPath, String label, int index, {bool visible = true}) {
    if (!visible) return const SizedBox.shrink();
    final isSelected = _selectedIndex == index;
    final color = isSelected ? Colors.orange : Colors.black54;

    return GestureDetector(
      onTap: () {
        if (index == 8) {
          launchWhatsAppChat();
        } else if (index == 1) {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const PassbookPage()));
        } else {
          _onItemTapped(index);
        }
      },
      child: Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset(iconPath, width: 28, height: 28, color: color),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(color: color, fontSize: 11)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_selectedIndex != 2) {
          _onItemTapped(2);
          return false;
        }
        return true;
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        drawer: _buildDrawer(),
       // appBar: _buildAppBar(context),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFFFFE7D1),
                Color(0xFFEFF8F0),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),

          child: SafeArea(
            child: Column(
              children: [
                _buildBodyHeader(),

                Expanded(
                  child: (_selectedIndex >= 0 && _selectedIndex < _screens.length)
                      ? _screens[_selectedIndex]
                      : const Center(child: Text("Error: Screen not found")),
                ),
              ],
            ),
          ),
        ),

        bottomNavigationBar: SafeArea(child: _buildBottomAppBar()),
      ),
    );
  }
}
