// File: lib/HomePage.dart
import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:marquee/marquee.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Helper/UserController.dart';
import '../KingStarline&Jackpot/KingJackpotDashboard.dart';
import '../KingStarline&Jackpot/KingStarlineDashboard.dart';
import '../components/closeBidDialogue.dart';
import '../game/GameScreen.dart';
import '../ulits/Constents.dart';

/// HomePage — merged final UI (gradient, marquee, pills, big card list)
class TranslationHelper {
  static Future<String> translate(String text, String lang) async {
    await Future.delayed(const Duration(milliseconds: 5));
    return text;
  }
}

// ---------------- Data Models ----------------
class HomeData {
  final bool status;
  final String msg;
  final List<Info>? result;

  HomeData({required this.status, required this.msg, this.result});

  factory HomeData.fromJson(Map<String, dynamic> json) => HomeData(
    status: _b(json["status"]),
    msg: json["msg"]?.toString() ?? '',
    result: json["info"] == null
        ? []
        : List<Info>.from(
            (json["info"] as List).map(
              (x) => Info.fromJson(x as Map<String, dynamic>),
            ),
          ),
  );
}

class Info {
  final int gameId;
  final String gameName;
  final String openTime;
  final String closeTime;
  final String result;
  final String statusText;
  final bool openSessionStatus;
  final bool closeSessionStatus;

  Info({
    required this.gameId,
    required this.gameName,
    required this.openTime,
    required this.closeTime,
    required this.result,
    required this.statusText,
    required this.openSessionStatus,
    required this.closeSessionStatus,
  });

  factory Info.fromJson(Map<String, dynamic> json) => Info(
    gameId: int.tryParse(json["gameId"].toString()) ?? 0,
    gameName: json["gameName"]?.toString() ?? '',
    openTime: json["openTime"]?.toString() ?? '',
    closeTime: json["closeTime"]?.toString() ?? '',
    result: json["result"]?.toString() ?? '',
    statusText: json["statusText"]?.toString() ?? '',
    openSessionStatus: _b(json["openSessionStatus"]),
    closeSessionStatus: _b(json["closeSessionStatus"]),
  );
}

bool _b(dynamic v) {
  if (v is bool) return v;
  if (v is num) return v != 0;
  if (v is String) {
    final s = v.trim().toLowerCase();
    return s == '1' || s == 'true' || s == 'yes' || s == 'y';
  }
  return false;
}

class ContactDetails {
  final String? mobileNo;
  final String? whatsappNo;
  final String? homepageContent;

  ContactDetails({this.mobileNo, this.whatsappNo, this.homepageContent});
}

HomeData homeDataFromJson(String str) =>
    HomeData.fromJson(json.decode(str) as Map<String, dynamic>);

// ---------------- HomePage ----------------
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<HomeData> _futureHomeData;
  late Future<ContactDetails?> _futureContactDetails;
  final GetStorage _storage = GetStorage();

  late final UserController userController = Get.isRegistered<UserController>()
      ? Get.find<UserController>()
      : Get.put(UserController(), permanent: true);

  final Map<String, String> _translatedUiStrings = {};
  late String _preferredLanguage;

  static const List<String> _uiKeysToTranslate = [
    "KING STARLINE",
    "King Jackpot",
    "Play Game",
    "Open Bid",
    "Close Bid",
    "Market Closed",
  ];

  @override
  void initState() {
    super.initState();
    _preferredLanguage = _storage.read('selectedLanguage') ?? 'en';
    _preTranslateUI();
    _futureHomeData = _fetchDashboardData();
    _futureContactDetails = fetchContactDetail();

    // react to auth/token changes
    everAll([userController.accessToken, userController.registerId], (_) {
      setState(() {
        _futureHomeData = _fetchDashboardData();
        _futureContactDetails = fetchContactDetail();
      });
    });
  }

  Future<void> _preTranslateUI() async {
    for (final key in _uiKeysToTranslate) {
      if (!_translatedUiStrings.containsKey(key) ||
          _translatedUiStrings[key] == key) {
        _translatedUiStrings[key] = await TranslationHelper.translate(
          key,
          _preferredLanguage,
        );
      }
    }
    if (mounted) setState(() {});
  }

  String _t(String k) => _translatedUiStrings[k] ?? k;

  Future<HomeData> _fetchDashboardData() async {
    final token = _storage.read('accessToken') ?? '';
    final regId = _storage.read('registerId') ?? '';

    if (token.isEmpty || regId.isEmpty) {
      log("Missing token/regId — returning empty HomeData");
      return HomeData(status: false, msg: "Not logged", result: []);
    }

    final response = await http.post(
      Uri.parse("${Constant.apiEndpoint}game-list"),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token",
      },
      body: json.encode({"registerId": regId}),
    );

    if (response.statusCode == 200) {
      try {
        return homeDataFromJson(response.body);
      } catch (e, st) {
        log("Parse error: $e", stackTrace: st);
        return HomeData(status: false, msg: "Parse error", result: []);
      }
    } else {
      log("game-list failed: ${response.statusCode} ${response.body}");
      return HomeData(status: false, msg: "Failed", result: []);
    }
  }

  Future<ContactDetails?> fetchContactDetail() async {
    try {
      final response = await http.get(
        Uri.parse("${Constant.apiEndpoint}contact-detail"),
        headers: {
          "Authorization": "Bearer ${_storage.read('accessToken') ?? ''}",
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        final contactInfo =
            (data['info'] as Map?)?['contactInfo'] as Map<String, dynamic>?;
        return ContactDetails(
          mobileNo: contactInfo?['mobileNo']?.toString(),
          whatsappNo: contactInfo?['whatsappNo']?.toString(),
          homepageContent: contactInfo?['homepageContent']?.toString(),
        );
      }
    } catch (e) {
      log("contact-detail error: $e");
    }
    return null;
  }

  Future<void> _handleRefresh() async {
    try {
      await userController.refreshEverything();
      setState(() {
        _futureHomeData = _fetchDashboardData();
        _futureContactDetails = fetchContactDetail();
      });
    } catch (e) {
      log("refresh error: $e");
    }
  }

  // Open/Call helpers (used by contact pills)
  Future<void> _openWhatsApp(String raw) async {
    var p = raw.replaceAll(RegExp(r'[^0-9]'), '');
    p = p.replaceFirst(RegExp(r'^0+'), '');
    if (p.length == 10) p = '91$p';
    final uri = Uri.parse('https://wa.me/$p');
    if (await canLaunchUrl(uri))
      await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // FULL PAGE TOP -> BOTTOM GRADIENT
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFE7D1), Color(0xFFEFF8F0)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: RefreshIndicator(
            color: Colors.orange,
            onRefresh: _handleRefresh,
            child: FutureBuilder<HomeData>(
              future: _futureHomeData,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Colors.orange),
                  );
                }
                if (snapshot.hasError) {
                  log("Future error: ${snapshot.error}");
                  return const Center(
                    child: Text(
                      "Error loading data.",
                      style: TextStyle(color: Colors.orange),
                    ),
                  );
                }
                final results = snapshot.data?.result ?? [];
                if (results.isEmpty) {
                  return ListView(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    children: [
                      // show marquee if available
                      FutureBuilder<ContactDetails?>(
                        future: _futureContactDetails,
                        builder: (context, s) {
                          if (s.hasData &&
                              (s.data?.homepageContent ?? '').isNotEmpty) {
                            return SizedBox(
                              height: 30,
                              child: Marquee(
                                text: s.data!.homepageContent!,
                                style: GoogleFonts.poppins(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                                blankSpace: 50,
                                velocity: 32,
                              ),
                            );
                          }
                          return const SizedBox();
                        },
                      ),
                      const SizedBox(height: 16),
                      const Center(
                        child: Text(
                          "No game data available.",
                          style: TextStyle(color: Colors.black54),
                        ),
                      ),
                    ],
                  );
                }

                return ListView(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  children: [
                    const SizedBox(height: 8),

                    // ------- MARQUEE (top) -------
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: FutureBuilder<ContactDetails?>(
                        future: _futureContactDetails,
                        builder: (context, s) {
                          if (s.hasData &&
                              (s.data?.homepageContent ?? '').isNotEmpty) {
                            return SizedBox(
                              height: 30,
                              child: Marquee(
                                text: s.data!.homepageContent! + '     ',
                                style: GoogleFonts.poppins(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                                blankSpace: 50,
                                velocity: 32,
                              ),
                            );
                          }
                          return const SizedBox.shrink();
                        },
                      ),
                    ),

                    const SizedBox(height: 12),

                    // ------- CATEGORY + CONTACT COMBINED WHITE CONTAINER -------
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // ---------- CATEGORY ROW ----------
                            Row(
                              children: [
                                Expanded(
                                  child: _categoryButton(
                                    title: _t("KING STARLINE"),
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              const KingStarlineDashboardScreen(),
                                        ),
                                      );
                                    },
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFFFFB347),
                                        Color(0xFFFFC458),
                                      ],
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _categoryButton(
                                    title: _t("King Jackpot"),
                                    textColor: Colors.white,
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              KingJackpotDashboard(),
                                        ),
                                      );
                                    },
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFF0B1223),
                                        Color(0xFF061031),
                                      ],
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 16),

                            // ---------- CONTACT ROW ----------
                            FutureBuilder<ContactDetails?>(
                              future: _futureContactDetails,
                              builder: (context, s) {
                                if (!s.hasData) return const SizedBox.shrink();
                                final c = s.data!;

                                return Row(
                                  children: [
                                    Expanded(
                                      child: _contactPill(
                                        icon:
                                            "assets/images/whatsapp_figma.png",
                                        text: c.whatsappNo ?? 'N/A',
                                        onTap: () =>
                                            _openWhatsApp(c.whatsappNo ?? ''),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: _contactPill(
                                        icon: "assets/images/call_figma.png",
                                        text: c.mobileNo ?? 'N/A',
                                        onTap: () {},
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),

                    // ------- BIG CARD (single card containing all games) -------
                    _buildBigGameCard(results),

                    const SizedBox(height: 24),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  // ---------------- Widgets ----------------

  Widget _categoryButton({
    required String title,
    required VoidCallback onTap,
    required Gradient gradient,
    Color textColor = Colors.black,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 45,
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(30),
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(width: 8),
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              softWrap: false,
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                color: textColor,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String getStatusIcon(String status) {
    status = status.toLowerCase();

    if (status.contains("open for today")) {
      return "assets/images/open_icon.png";
    }
    if (status.contains("closed for today")) {
      return "assets/images/closed_icon.png";
    }
    if (status.contains("holiday for today")) {
      return "assets/images/holiday_icon.png";
    }

    return "assets/images/closed_icon.png"; // default
  }

  Widget _contactPill({
    required String icon,
    required String text,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          children: [
            Image.asset(
              icon,
              width: 24,
              height: 24,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.phone, color: Colors.green),
            ),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                text,
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String getPlayIcon(String status) {
    status = status.toLowerCase();

    if (status.contains("open for today")) {
      return "assets/images/play3.png"; // आपकी open image
    } else if (status.contains("closed for today")) {
      return "assets/images/play6.png"; // आपकी open image
    } else if (status.contains("holiday for today")) {
      return "assets/images/play4.png"; // आपकी closed image
    }
    return "assets/images/play4.png"; // आपकी closed image
  }

  Widget _buildBigGameCard(List<Info> results) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: results.asMap().entries.map((entry) {
          final index = entry.key;
          final game = entry.value;

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey.shade300),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 6,
                  spreadRadius: 1,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child:
                          // Replace the Row inside game card with this Column structure:
                          // Replace the Row inside game card with this Column structure:
                          Column(
                            children: [
                              // Main Row with game info and play button
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  // Left side - Game name and result in Column
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        game.gameName.toUpperCase(),
                                        style: GoogleFonts.poppins(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w800,
                                          color: const Color(0xFFFFB347),
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        game.result.isEmpty
                                            ? '***_**_***'
                                            : game.result,
                                        style: GoogleFonts.poppins(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ],
                                  ),

                                  // Right side - Play button
                                  GestureDetector(
                                    onTap: () {
                                      final s = game.statusText.toLowerCase();
                                      if (s.contains("closed for today") ||
                                          s.contains("holiday for today")) {
                                        closeBidDialogue(
                                          context: context,
                                          gameName: game.gameName,
                                          openResultTime: game.openTime,
                                          openBidLastTime: game.openTime,
                                          closeResultTime: game.closeTime,
                                          closeBidLastTime: game.closeTime,
                                        );
                                      } else {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => GameMenuScreen(
                                              title: game.gameName,
                                              gameId: game.gameId,
                                              openSessionStatus:
                                                  game.openSessionStatus,
                                              closeSessionStatus:
                                                  game.closeSessionStatus,
                                            ),
                                          ),
                                        );
                                      }
                                    },
                                    child: ClipOval(
                                      child: Image.asset(
                                        getPlayIcon(game.statusText),
                                        width: 55, // ⬅️ Width set
                                        height: 55, // ⬅️ Height set
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 8),

                              // Status text below - Left aligned
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  game.statusText,
                                  style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color:
                                        game.statusText.toLowerCase().contains(
                                          "open",
                                        )
                                        ? Colors.green
                                        : Colors.red,
                                  ),
                                ),
                              ),

                              const SizedBox(height: 8),

                              // Full width divider
                              Divider(
                                color: Colors.grey.shade300,
                                thickness: 1,
                                height: 1,
                              ),

                              const SizedBox(height: 8),

                              // Bid times row
                              Row(
                                children: [
                                  Expanded(
                                    child: Row(
                                      children: [
                                        Text(
                                          "Open Bids: ",
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          game.openTime,
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 20),
                                  Expanded(
                                    child: Row(
                                      children: [
                                        Text(
                                          "Close Bids: ",
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          game.closeTime,
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                    ),

                    // GestureDetector(
                    //   onTap: () {
                    //     final s = game.statusText.toLowerCase();
                    //     if (s.contains("closed for today") ||
                    //         s.contains("holiday for today")) {
                    //       closeBidDialogue(
                    //         context: context,
                    //         gameName: game.gameName,
                    //         openResultTime: game.openTime,
                    //         openBidLastTime: game.openTime,
                    //         closeResultTime: game.closeTime,
                    //         closeBidLastTime: game.closeTime,
                    //       );
                    //     } else {
                    //       Navigator.push(
                    //         context,
                    //         MaterialPageRoute(
                    //           builder: (_) => GameMenuScreen(
                    //             title: game.gameName,
                    //             gameId: game.gameId,
                    //             openSessionStatus: game.openSessionStatus,
                    //             closeSessionStatus: game.closeSessionStatus,
                    //           ),
                    //         ),
                    //       );
                    //     }
                    //   },
                    //   child: Container(
                    //     width: 54,
                    //     height: 54,
                    //     decoration: const BoxDecoration(
                    //       shape: BoxShape.circle,
                    //       gradient: LinearGradient(
                    //         colors: [Color(0xFFFFB347), Color(0xFFFFC458)],
                    //         begin: Alignment.topLeft,
                    //         end: Alignment.bottomRight,
                    //       ),
                    //     ),
                    //     child: const Icon(
                    //       Icons.play_arrow,
                    //       color: Colors.white,
                    //       size: 32,
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
