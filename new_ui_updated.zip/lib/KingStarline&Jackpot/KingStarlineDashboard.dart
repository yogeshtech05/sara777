import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:new_sara/Bids/KingStarlineResultHis/KingStarlineResultHis.dart';
import 'package:new_sara/KingStarline&Jackpot/KingStarlineOptionScreen.dart';

import '../components/KingJackpotBiddingClosedDialog.dart';
import '../ulits/Constents.dart';

/// ---- Data Model ----
class StarlineGame {
  final int id; // from gameId
  final String time; // from gameName (e.g., "09:30 PM")
  final String status; // from statusText
  final String result; // from result
  final bool isClosed; // !playStatus
  final String openTime; // from openTime
  final String closeTime; // from closeTime
  final String additionalInfo; // "Bid closed at <closeTime>" when closed

  StarlineGame({
    required this.id,
    required this.time,
    required this.status,
    required this.result,
    required this.isClosed,
    required this.openTime,
    required this.closeTime,
    this.additionalInfo = '',
  });

  static bool _toBool(dynamic v) {
    if (v is bool) return v;
    if (v is int) return v != 0;
    if (v is String) {
      final s = v.trim().toLowerCase();
      return s == 'true' ||
          s == '1' ||
          s == 'open' ||
          s == 'active' ||
          s == 'running';
    }
    return false;
  }

  factory StarlineGame.fromJson(Map<String, dynamic> json) {
    final int gameId = () {
      final v = json['gameId'];
      if (v is int) return v;
      if (v is String) return int.tryParse(v) ?? 0;
      return 0;
    }();

    final String gameName = (json['gameName'] ?? 'N/A').toString();
    final String result = (json['result'] ?? '****-*').toString();
    final String statusText = (json['statusText'] ?? 'Unknown').toString();
    final bool playStatus = _toBool(json['playStatus']); // true => open
    final String closeTime = (json['closeTime'] ?? '--:--').toString();
    final String openTime = (json['openTime'] ?? '--:--').toString();

    final bool closed = !playStatus;
    final String displayStatus = statusText.isEmpty
        ? (closed ? 'Closed' : 'Open')
        : statusText;
    final String displayAdditionalInfo = closed
        ? 'Bid closed at $closeTime'
        : '';

    return StarlineGame(
      id: gameId,
      time: gameName,
      status: displayStatus,
      result: result,
      isClosed: closed,
      openTime: openTime,
      closeTime: closeTime,
      additionalInfo: displayAdditionalInfo,
    );
  }
}

/// ---- Screen ----
class KingStarlineDashboardScreen extends StatefulWidget {
  const KingStarlineDashboardScreen({super.key});

  @override
  State<KingStarlineDashboardScreen> createState() =>
      _KingStarlineDashboardScreenState();
}

class _KingStarlineDashboardScreenState
    extends State<KingStarlineDashboardScreen> {
  bool _notificationsEnabled = true;
  List<StarlineGame> _gameTimes = [];
  bool _isLoading = true;
  String _errorMessage = '';
  final GetStorage _storage = GetStorage();

  // Non-nullable registeredId (loaded from local storage)
  String _registeredId = '';

  @override
  void initState() {
    super.initState();
    _loadAuthData();
    _fetchGameList();
  }

  void _loadAuthData() {
    // Signup/Login par jo save kiya tha, wahi se seedha utha rahe hain
    final rid = _storage.read('registerId')?.toString() ?? '';
    _registeredId = rid;
    log(
      'RegisteredId loaded: ${_registeredId.isEmpty ? "(empty)" : _registeredId}',
    );
  }

  Map<String, String> _buildHeaders(
    String accessToken, {
    String? deviceId,
    String? deviceName,
    bool accountStatus = true,
  }) {
    final now = DateTime.now();
    return {
      'deviceId':
          deviceId ??
          (_storage.read('deviceId')?.toString() ?? 'unknown_device'),
      'deviceName':
          deviceName ??
          (_storage.read('deviceName')?.toString() ?? 'unknown_model'),
      'accessStatus': accountStatus ? '1' : '0',
      'Content-Type': 'application/json; charset=utf-8',
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken',
      // helpful for backend time reconciliation
      'x-client-time': now.toIso8601String(),
      'x-tz-offset-mins': now.timeZoneOffset.inMinutes.toString(),
      'x-tz-name': now.timeZoneName,
    };
  }

  Future<void> _fetchGameList() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    final String? accessToken = _storage.read('accessToken');
    final String? registerId = _storage.read('registerId');
    final bool accountStatus = (_storage.read('accountStatus') ?? true) == true;

    if (accessToken == null || accessToken.isEmpty) {
      log('Error: Access token not found. Cannot fetch Starline game list.');
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Access token not found. Please log in again.';
        _isLoading = false;
      });
      return;
    }

    if (registerId == null || registerId.isEmpty) {
      log('Error: Register ID not found. Cannot fetch Starline game list.');
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Register ID not found. Please log in again.';
        _isLoading = false;
      });
      return;
    }

    final url = Uri.parse('${Constant.apiEndpoint}starline-game-list');
    final headers = _buildHeaders(accessToken, accountStatus: accountStatus);
    final body = jsonEncode({'registerId': registerId});

    try {
      final response = await http.post(url, headers: headers, body: body);

      log('Starline Game List API Status: ${response.statusCode}');
      log('Starline Game List API Body: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData =
            json.decode(response.body) as Map<String, dynamic>;

        if (responseData['status'] == true && responseData['info'] is List) {
          final List rawList = responseData['info'] as List;
          final games = rawList
              .map(
                (e) =>
                    StarlineGame.fromJson((e as Map).cast<String, dynamic>()),
              )
              .toList();

          // Sort by time if parseable (hh:mm a)
          final fmt = DateFormat('hh:mm a');
          games.sort((a, b) {
            DateTime? ta, tb;
            try {
              final pa = fmt.parse(a.time);
              ta = DateTime(1970, 1, 1, pa.hour, pa.minute);
            } catch (_) {}
            try {
              final pb = fmt.parse(b.time);
              tb = DateTime(1970, 1, 1, pb.hour, pb.minute);
            } catch (_) {}
            if (ta == null && tb == null) return 0;
            if (ta == null) return 1;
            if (tb == null) return -1;
            return ta.compareTo(tb);
          });

          if (!mounted) return;
          setState(() {
            _gameTimes = games;
            _isLoading = false;
          });
        } else {
          final msg = (responseData['msg'] ?? 'Failed to load game data.')
              .toString();
          log('Starline Game List API Error: $msg');
          if (!mounted) return;
          setState(() {
            _errorMessage = msg;
            _isLoading = false;
          });
        }
      } else {
        if (!mounted) return;
        setState(() {
          _errorMessage =
              'Error ${response.statusCode}: ${response.reasonPhrase ?? 'Unknown error'}\n${response.body}';
          _isLoading = false;
        });
      }
    } catch (e) {
      log('Exception during Starline Game List API call: $e');
      if (!mounted) return;
      setState(() {
        _errorMessage = 'An error occurred: $e';
        _isLoading = false;
      });
    }
  }

  void _onPlayTap(StarlineGame game) {
    log(
      'Play Game tapped => id=${game.id}, time=${game.time}, status=${game.status}, isClosed=${game.isClosed}',
    );

    if (game.isClosed) {
      showDialog(
        context: context,
        builder: (_) => KingJackpotBiddingClosedDialog(
          time: game.time,
          resultTime: game.openTime,
          bidLastTime: game.closeTime,
        ),
      );
      return;
    }

    // BEST PRACTICE: registeredId must be non-empty, warna navigate mat karo
    if (_registeredId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Register ID missing. Please log in again.'),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => KingStarlineOptionScreen(
          title: 'King Starline',
          gameTime: game.time,
          starlineGameId: game.id, // session/game id
          paanaStatus: !game.isClosed, // open/close info
          registeredId: _registeredId, // non-null String
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(130),
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFE8D1), Color(0xFFEFF8F0)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(40),
              bottomRight: Radius.circular(40),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios_new,
                        color: Colors.black,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      "STARLINE DASHBOARD",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: const [
                          Icon(Icons.history, color: Colors.black87),
                          SizedBox(width: 8),
                          Text(
                            "History",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),


                      Row(
                        children: [
                          const Text(
                            "Notification",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Switch(
                            value: _notificationsEnabled,
                            activeColor: Colors.orange,
                            onChanged: (v) =>
                                setState(() => _notificationsEnabled = v),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),

      body: SafeArea(
        child: Column(
          children: [
            // Container(
            //   color: Colors.grey.shade300,
            //   padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       InkWell(
            //         borderRadius: BorderRadius.circular(8),
            //         onTap: () {
            //           //   Navigate to the history
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(
            //               builder: (_) => KingStarlineResultScreen(),
            //             ),
            //           );
            //         },
            //         child: const Padding(
            //           padding: EdgeInsets.symmetric(
            //             vertical: 8.0,
            //             horizontal: 4.0,
            //           ),
            //           child: Row(
            //             mainAxisSize: MainAxisSize.min,
            //             children: [
            //               SizedBox(width: 5),
            //               Icon(
            //                 Icons.calendar_month,
            //                 color: Colors.black,
            //                 size: 24,
            //               ),
            //               SizedBox(width: 4),
            //               Text(
            //                 'History',
            //                 style: TextStyle(
            //                   color: Colors.black,
            //                   fontSize: 14,
            //                   fontWeight: FontWeight.w500,
            //                 ),
            //               ),
            //             ],
            //           ),
            //         ),
            //       ),
            //       Row(
            //         mainAxisSize: MainAxisSize.min,
            //         children: [
            //           const Text(
            //             'Notifications',
            //             style: TextStyle(color: Colors.black, fontSize: 14),
            //           ),
            //           Transform.scale(
            //             scale: 0.8,
            //             child: Switch(
            //               value: _notificationsEnabled,
            //               onChanged: (v) =>
            //                   setState(() => _notificationsEnabled = v),
            //               activeTrackColor: Colors.teal[300],
            //               activeColor: Colors.teal,
            //               inactiveTrackColor: Colors.grey[300],
            //               inactiveThumbColor: Colors.grey,
            //             ),
            //           ),
            //         ],
            //       ),
            //     ],
            //   ),
            // ),
            // Divider(height: 1, thickness: 1, color: Colors.grey[200]),
            const SizedBox(height: 5),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      _buildInfoCard('Single Digit', '10-100'),
                      const SizedBox(width: 5),
                      _buildInfoCard('Double Pana', '10-3200'),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      _buildInfoCard('Single Pana', '10-1600'),
                      const SizedBox(width: 10),
                      _buildInfoCard('Triple Pana', '10-10000'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 5),
            if (_isLoading)
              const Expanded(
                child: Center(
                  child: CircularProgressIndicator(color: Colors.orange),
                ),
              )
            else if (_errorMessage.isNotEmpty)
              Expanded(
                child: Center(
                  child: Text(
                    _errorMessage,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.orange.shade700,
                      fontSize: 16,
                    ),
                  ),
                ),
              )
            else
              Expanded(
                child: Container(
                  color: Colors.white,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: _gameTimes.length,
                    itemBuilder: (_, i) {
                      final g = _gameTimes[i];
                      return _buildGameTimeListItem(game: g);
                    },
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.orange.shade200, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Color(0xFF333333),
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.orange.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameTimeListItem({required StarlineGame game}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          /// TIME + STATUS
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  game.time,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  game.isClosed ? "Closed for Today" : "Running Now",
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: game.isClosed ? Colors.red : Colors.green.shade700,
                  ),
                ),
              ],
            ),
          ),

          /// RESULT BOX (Black Oval)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Text(
              game.result,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: Colors.orange,
              ),
            ),
          ),

          const SizedBox(width: 12),

          /// PLAY BUTTON (as screenshot)
          GestureDetector(
            onTap: () => _onPlayTap(game),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: Colors.orange.shade600, width: 0.8),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 12,
                    backgroundColor: Colors.orange,
                    child: Icon(Icons.play_arrow,
                        color: Colors.white, size: 22),
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    "Play Gamee",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

}
