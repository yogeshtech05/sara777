import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

class GameRateScreen extends StatefulWidget {
  const GameRateScreen({super.key});

  @override
  State<GameRateScreen> createState() => _GameRateScreenState();
}

class _GameRateScreenState extends State<GameRateScreen> {
  Map<String, dynamic>? gameRates;

  @override
  void initState() {
    super.initState();
    fetchGameRates();
  }

  Future<void> fetchGameRates() async {
    String token = GetStorage().read("accessToken");
    final url = Uri.parse('https://admin.sara777.app/api/v1/game-rate');
    final response = await http.get(
      url,
      headers: {
        'deviceId': 'qwert',
        'deviceName': 'sm2233',
        'accessStatus': '1',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      setState(() {
        gameRates = jsonData['info'];
      });
    } else {
      debugPrint('Failed to load game rates: ${response.statusCode}');
    }
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.bold,
            color: Color(0xFFF9A825), // same orange
          ),
        ),
      ),
    );
  }


  Widget rateRow(String label, dynamic value) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
              Text(
                value.toString(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),

        // Divider like screenshot
        Container(height: 1, color: Colors.grey.shade300),
      ],
    );
  }


  Widget buildRates(String title, Map<String, dynamic> rates) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        sectionTitle(title),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Column(
            children: rates.entries.map((entry) {
              return rateRow(formatLabel(entry.key), entry.value);
            }).toList(),
          ),
        ),

        const SizedBox(height: 20),
      ],
    );
  }


  String formatLabel(String key) {
    switch (key) {
      case 'singleDigit':
        return 'Single';
      case 'jodi':
        return 'Jodi';
      case 'singlePanna':
        return 'Single Panna';
      case 'doublePanna':
        return 'Double Panna';
      case 'triplePanna':
        return 'Triple Panna';
      case 'halfSangam':
        return 'Half Sangam';
      case 'fullSangam':
        return 'Full Sangam';
      default:
        return key;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
        color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: gameRates == null
                ? const Center(
                    child: CircularProgressIndicator(color: Colors.orange),
                  )
                : SingleChildScrollView(
                    child: Column(
                      children: [
                        buildRates(
                          'Game Win Ratio for All Bids',
                          gameRates!['gameRate'],
                        ),
                        buildRates(
                          'King Starline Game Win Ratio',
                          gameRates!['starlineGameRate'],
                        ),
                        buildRates(
                          'King Jackpot Win Ratio',
                          gameRates!['jackpotGameRate'],
                        ),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
