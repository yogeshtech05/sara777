import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../BidService.dart';
import '../../Helper/UserController.dart';
import '../../components/AnimatedMessageBar.dart';
import '../../components/BidConfirmationDialog.dart';
import '../../components/BidFailureDialog.dart';
import '../../components/BidSuccessDialog.dart';

class SingleDigitBetScreen extends StatefulWidget {
  final String title;
  final String gameCategoryType;
  final int gameId;
  final String gameName;
  final bool selectionStatus;

  const SingleDigitBetScreen({
    super.key,
    required this.title,
    required this.gameId,
    required this.gameName,
    required this.gameCategoryType,
    required this.selectionStatus,
  });

  @override
  State<SingleDigitBetScreen> createState() => _SingleDigitBetScreenState();
}

class _SingleDigitBetScreenState extends State<SingleDigitBetScreen> {
  final List<String> gameTypesOptions = ["Open", "Close"];
  late String selectedGameBetType;

  // Controllers for each digit (0-9)
  final Map<String, TextEditingController> digitControllers = {};

  final List<String> digitOptions = [
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
  ];

  List<Map<String, String>> addedEntries = [];
  late GetStorage storage = GetStorage();
  late BidService _bidService;
  late String accessToken;
  late String registerId;
  late String preferredLanguage;
  bool accountStatus = false;
  late int walletBalance;
  bool _isApiCalling = false;

  final UserController userController = Get.put(UserController());

  final String _deviceId = 'test_device_id_flutter';
  final String _deviceName = 'test_device_name_flutter';

  String? _messageToShow;
  bool _isErrorForMessage = false;
  Key _messageBarKey = UniqueKey();
  Timer? _messageDismissTimer;

  @override
  void initState() {
    super.initState();
    _bidService = BidService(storage);
    _loadInitialData();

    double _walletBalance = double.parse(userController.walletBalance.value);
    walletBalance = _walletBalance.toInt();

    // Initialize controllers for each digit
    for (String digit in digitOptions) {
      digitControllers[digit] = TextEditingController();
    }
  }

  Future<void> _loadInitialData() async {
    accessToken = storage.read('accessToken') ?? '';
    registerId = storage.read('registerId') ?? '';
    accountStatus = userController.accountStatus.value;
    preferredLanguage = storage.read('selectedLanguage') ?? 'en';

    selectedGameBetType = widget.selectionStatus
        ? gameTypesOptions[0]
        : gameTypesOptions[1];
  }

  @override
  void dispose() {
    for (var controller in digitControllers.values) {
      controller.dispose();
    }
    _messageDismissTimer?.cancel();
    super.dispose();
  }

  void _showMessage(String message, {bool isError = false}) {
    _messageDismissTimer?.cancel();
    if (!mounted) return;
    setState(() {
      _messageToShow = message;
      _isErrorForMessage = isError;
      _messageBarKey = UniqueKey();
    });
    _messageDismissTimer = Timer(const Duration(seconds: 3), _clearMessage);
  }

  void _clearMessage() {
    if (mounted) {
      setState(() {
        _messageToShow = null;
      });
    }
    _messageDismissTimer?.cancel();
  }

  void _updateBids() {
    _clearMessage();
    if (_isApiCalling) return;

    // Clear existing entries
    addedEntries.clear();

    int totalPoints = 0;

    // Collect all bids from text fields
    for (String digit in digitOptions) {
      final points = digitControllers[digit]!.text.trim();

      if (points.isNotEmpty) {
        int? parsedPoints = int.tryParse(points);
        if (parsedPoints == null || parsedPoints < 10 || parsedPoints > 1000) {
          _showMessage(
            'Points for digit $digit must be between 10 and 1000.',
            isError: true,
          );
          return;
        }
        totalPoints += parsedPoints;

        addedEntries.add({
          "digit": digit,
          "points": points,
          "type": selectedGameBetType,
        });
      }
    }

    if (totalPoints > walletBalance) {
      _showMessage(
        'Insufficient wallet balance to place these bids.',
        isError: true,
      );
      return;
    }

    setState(() {});
  }

  int _getTotalPoints() {
    return addedEntries.fold(
      0,
      (sum, item) => sum + (int.tryParse(item['points'] ?? '0') ?? 0),
    );
  }

  void _showConfirmationDialog() {
    _clearMessage();
    _updateBids();

    if (addedEntries.isEmpty) {
      _showMessage('Please add at least one bid.', isError: true);
      return;
    }

    final List<Map<String, String>> bidsForConfirmation = addedEntries.map((
      bid,
    ) {
      return {
        "digit": bid['digit']!,
        "points": bid['points']!,
        "type": bid['type']!,
        "pana": "",
      };
    }).toList();

    final int totalPointsForConfirmation = bidsForConfirmation.fold(
      0,
      (sum, item) => sum + (int.tryParse(item['points'] ?? '0') ?? 0),
    );

    if (walletBalance < totalPointsForConfirmation) {
      _showMessage(
        'Insufficient wallet balance to place this bid.',
        isError: true,
      );
      return;
    }

    final String formattedDate = DateFormat(
      'dd MMM yyyy, hh:mm a',
    ).format(DateTime.now());

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return BidConfirmationDialog(
          gameTitle: widget.title,
          gameDate: formattedDate,
          bids: bidsForConfirmation,
          totalBids: bidsForConfirmation.length,
          totalBidsAmount: totalPointsForConfirmation,
          walletBalanceBeforeDeduction: walletBalance,
          walletBalanceAfterDeduction:
              (walletBalance - totalPointsForConfirmation).toString(),
          gameId: widget.gameId.toString(),
          gameType: widget.gameCategoryType,
          onConfirm: () async {
            await _placeFinalBids();
          },
        );
      },
    );
  }

  Future<void> _placeFinalBids() async {
    setState(() {
      _isApiCalling = true;
    });

    final Map<String, String> bidsToSubmit = {};
    int totalPointsForSubmission = 0;

    for (var entry in addedEntries) {
      bidsToSubmit[entry['digit']!] = entry['points']!;
      totalPointsForSubmission += (int.tryParse(entry['points']!) ?? 0);
    }

    if (bidsToSubmit.isEmpty) {
      _showMessage('No bids to submit.', isError: true);
      setState(() {
        _isApiCalling = false;
      });
      return;
    }

    final result = await _bidService.placeFinalBids(
      gameName: widget.title,
      accessToken: accessToken,
      registerId: registerId,
      deviceId: _deviceId,
      deviceName: _deviceName,
      accountStatus: accountStatus,
      bidAmounts: bidsToSubmit,
      selectedGameType: selectedGameBetType,
      gameId: widget.gameId,
      gameType: widget.gameCategoryType,
      totalBidAmount: totalPointsForSubmission,
    );

    if (!mounted) {
      _isApiCalling = false;
      return;
    }

    setState(() {
      _isApiCalling = false;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!context.mounted) return;

      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) {
          log("resultour  log : ${result['status']}");
          if (result['status'] == true) {
            return const BidSuccessDialog();
          } else {
            return BidFailureDialog(errorMessage: result['msg']);
          }
        },
      );

      if (result['status'] && context.mounted) {
        final int newBalance = walletBalance - totalPointsForSubmission;
        setState(() {
          walletBalance = newBalance;
          addedEntries.clear();
          // Clear all text fields
          for (var controller in digitControllers.values) {
            controller.clear();
          }
          bidsToSubmit.clear();
        });
        await _bidService.updateWalletBalance(newBalance);
        _showMessage('Bids submitted successfully!');
      } else {
        _showMessage(result['msg'] ?? "Bid failed.", isError: true);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFE8D1), Color(0xFFEFF8F0)],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 12),

              // Main Content Container
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Column(
                        children: [
                          // Header
                          const SizedBox(height: 12),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16.0,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                GestureDetector(
                                  onTap: () => Navigator.pop(context),
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.grey, // grey border color
                                        width: 1, // border thickness
                                      ),
                                    ),

                                    child: const Icon(
                                      Icons.arrow_back,
                                      color: Colors.black,
                                      size: 20,
                                    ),
                                  ),
                                ),
                                Text(
                                  widget.title,
                                  style: const TextStyle(
                                    color: Colors.black,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 1, // only one line allowed
                                  overflow: TextOverflow.ellipsis, // show ...
                                ),

                                // 🔥 WALLET CAPSULE (dark blue)
                                Obx(
                                  () => userController.accountStatus.value
                                      ? Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 16,
                                            vertical: 8,
                                          ),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFF0B1223),
                                            borderRadius: BorderRadius.circular(
                                              40,
                                            ),
                                          ),
                                          child: Row(
                                            children: [
                                              Image.asset(
                                                "assets/images/ic_wallet.png",
                                                width: 20,
                                                height: 20,
                                                color: Colors.white,
                                              ),
                                              const SizedBox(width: 8),
                                              Text(
                                                "₹${userController.walletBalance.value}",
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ],
                                          ),
                                        )
                                      : const SizedBox.shrink(),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),

                          //   const SizedBox(height: 20),
                          // Game Type Selector
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Select Game Type :',
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black87,
                                  ),
                                ),
                                _buildDropdown(widget.selectionStatus),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          const Divider(thickness: 1, height: 1),
                          const SizedBox(height: 16),
                          // Grid of Digits
                          Expanded(
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                              child: Column(
                                children: [
                                  for (
                                    int i = 0;
                                    i < digitOptions.length;
                                    i += 2
                                  )
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        bottom: 12,
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: _buildDigitCard(
                                              digitOptions[i],
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: i + 1 < digitOptions.length
                                                ? _buildDigitCard(
                                                    digitOptions[i + 1],
                                                  )
                                                : const SizedBox(),
                                          ),
                                        ],
                                      ),
                                    ),
                                  const SizedBox(height: 80),
                                ],
                              ),
                            ),
                          ),
                          _buildBottomBar(),
                        ],
                      ),
                      if (_messageToShow != null)
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          child: AnimatedMessageBar(
                            key: _messageBarKey,
                            message: _messageToShow!,
                            isError: _isErrorForMessage,
                            onDismissed: _clearMessage,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown(bool selectionStatus) {
    List<String> filteredOptions = selectionStatus
        ? ['Open', 'Close']
        : ['Close'];

    if (!filteredOptions.contains(selectedGameBetType)) {
      selectedGameBetType = filteredOptions.first;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
      decoration: BoxDecoration(
        color: const Color(0xFFFFCFCFC),
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedGameBetType,
          icon: const Icon(Icons.keyboard_arrow_down, color: Colors.orange),
          onChanged: _isApiCalling
              ? null
              : (String? newValue) {
                  setState(() {
                    selectedGameBetType = newValue!;
                    _clearMessage();
                  });
                },
          items: filteredOptions.map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildDigitCard(String digit) {
    return Container(
      height: 45,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: const Color(0xFFFCFCFC),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          // Digit Circle
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xffECEBEB),
              border: Border.all(color: Colors.grey.shade300, width: 1.5),
            ),
            child: Center(
              child: Text(
                digit,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.orange,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Input Field
          Expanded(
            child: TextField(
              controller: digitControllers[digit],
              keyboardType: TextInputType.number,
              enabled: !_isApiCalling,
              onChanged: (value) => _updateBids(),
              onTap: _clearMessage,
              style: GoogleFonts.poppins(fontSize: 13),
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(4),
              ],
              decoration: InputDecoration(
                hintText: 'Enter Points',
                hintStyle: GoogleFonts.poppins(
                  fontSize: 13,
                  color: Colors.black,
                ),
                filled: false,
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
                isDense: true,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar() {
    int totalBids = addedEntries.length;
    int totalPoints = _getTotalPoints();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Bids',
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  color: Colors.grey.shade600,
                ),
              ),
              Text(
                '$totalBids',
                style: GoogleFonts.poppins(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Points',
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  color: Colors.grey.shade600,
                ),
              ),
              Text(
                '$totalPoints',
                style: GoogleFonts.poppins(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          ElevatedButton(
            onPressed: (_isApiCalling || totalBids == 0)
                ? null
                : _showConfirmationDialog,
            style: ElevatedButton.styleFrom(
              backgroundColor: (_isApiCalling || totalBids == 0)
                  ? Colors.grey
                  : Colors.orange,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              elevation: 2,
            ),
            child: _isApiCalling
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Text(
                    'Submit',
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
