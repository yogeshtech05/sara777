import 'dart:async'; // For Timer

import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For TextInputFormatter
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart'; // For GoogleFonts
import 'package:intl/intl.dart';

import '../../BidService.dart'; // Assuming BidService.dart is in the parent directory
import '../../Helper/UserController.dart';
import '../../components/AnimatedMessageBar.dart'; // Assuming this component is separate
import '../../components/BidConfirmationDialog.dart';
import '../../components/BidFailureDialog.dart';
import '../../components/BidSuccessDialog.dart';

// Create a simple model for a single bid entry.
// This is a good practice to keep data structured.
class BidEntry {
  final String digit;
  final String points;
  final String type;

  BidEntry({required this.digit, required this.points, required this.type});
}

class SingleDigitsBulkScreen extends StatefulWidget {
  final String title;
  final int gameId;
  final String gameName;
  final String gameType; // This should be like "singleDigits"
  final bool selectionStatus;

  const SingleDigitsBulkScreen({
    Key? key,
    required this.title,
    required this.gameId,
    required this.gameName,
    required this.gameType,
    required this.selectionStatus,
  }) : super(key: key);

  @override
  State<SingleDigitsBulkScreen> createState() => _SingleDigitsBulkScreenState();
}

class _SingleDigitsBulkScreenState extends State<SingleDigitsBulkScreen> {
  late String selectedGameType =
      'Open'; // This refers to sessionType (Open/Close)
  final List<String> gameTypes = ['Open', 'Close'];

  final TextEditingController pointsController = TextEditingController();

  Color dropdownBorderColor = Colors.black;
  Color textFieldBorderColor = Colors.black;

  // Change bidAmounts to store a list of BidEntry objects
  // This new structure stores all the necessary data for each bid.
  List<BidEntry> bidEntries = [];

  late GetStorage storage;
  late BidService _bidService; // Declare BidService

  late String _accessToken; // Renamed to private to match common convention
  late String _registerId; // Renamed to private
  bool _accountStatus = false; // Renamed to private
  int _walletBalance = 0; // Renamed to private, directly storing int

  // --- AnimatedMessageBar State Management ---
  String? _messageToShow;
  bool _isErrorForMessage = false;
  Key _messageBarKey = UniqueKey();
  Timer? _messageDismissTimer; // Initialize Timer here
  // --- End AnimatedMessageBar State Management ---

  bool _isApiCalling = false; // To show loading during API calls
  bool _isWalletLoading = true; // Added for initial wallet loading state

  // Device info (can be loaded from storage or directly assigned for testing)
  String _deviceId = 'test_device_id_flutter';
  String _deviceName = 'test_device_name_flutter';

  final UserController userController = Get.put(UserController());

  @override
  void initState() {
    super.initState();
    storage = GetStorage(); // Initialize GetStorage
    _bidService = BidService(storage); // Initialize BidService with GetStorage
    _loadInitialData();

    // Initialize walletBalance from storage as String
    double _walletBalanceDouble = double.parse(
      userController.walletBalance.value,
    );
    _walletBalance = _walletBalanceDouble.toInt();
    _loadInitialData();
  }

  // Asynchronously loads initial user data and wallet balance from GetStorage
  Future<void> _loadInitialData() async {
    _accessToken = storage.read('accessToken') ?? '';
    _registerId = storage.read('registerId') ?? '';
    _accountStatus = storage.read('accountStatus') ?? false;
  }

  @override
  void dispose() {
    pointsController.dispose();
    _messageDismissTimer?.cancel(); // Cancel the timer on dispose
    super.dispose();
  }

  // --- AnimatedMessageBar Helper Methods ---
  void _showMessage(String message, {bool isError = false}) {
    _messageDismissTimer?.cancel(); // Cancel any existing timer
    if (!mounted) return;
    setState(() {
      _messageToShow = message;
      _isErrorForMessage = isError;
      _messageBarKey = UniqueKey(); // Force rebuild of message bar
    });
    // Set a timer to dismiss the message after 3 seconds, consistent with Jodi
    _messageDismissTimer = Timer(const Duration(seconds: 3), _clearMessage);
  }

  void _clearMessage() {
    if (mounted) {
      setState(() {
        _messageToShow = null;
      });
    }
    _messageDismissTimer
        ?.cancel(); // Ensure timer is cancelled when message is cleared manually
  }
  // --- End AnimatedMessageBar Helper Methods ---

  void onNumberPressed(String number) {
    _clearMessage();
    if (_isApiCalling) return; // Prevent adding bids while API is in progress

    final amount = pointsController.text.trim();
    if (amount.isEmpty) {
      _showMessage('Please enter an amount first.', isError: true);
      return;
    }

    int? parsedAmount = int.tryParse(amount);
    if (parsedAmount == null || parsedAmount < 10 || parsedAmount > 1000) {
      // Assuming a max bid of 1000, adjust as per your rules
      _showMessage('Points must be between 10 and 1000.', isError: true);
      return;
    }

    // Check if a bid for this digit already exists with the SAME type
    final existingBidIndex = bidEntries.indexWhere(
      (bid) =>
          bid.digit == number && bid.type == selectedGameType.toUpperCase(),
    );

    // Calculate total points with the new bid to check against wallet balance
    int currentTotalPoints = _getTotalPoints();
    int pointsForThisBid = parsedAmount;

    // If the bid already exists, subtract its old points before adding new ones
    if (existingBidIndex != -1) {
      currentTotalPoints -=
          int.tryParse(bidEntries[existingBidIndex].points) ?? 0;
    }

    int totalPointsWithNewBid = currentTotalPoints + pointsForThisBid;

    if (totalPointsWithNewBid > _walletBalance) {
      _showMessage(
        'Insufficient wallet balance to place these bids.',
        isError: true,
      );
      return;
    }

    // Create a new bid entry
    final newBid = BidEntry(
      digit: number,
      points: amount,
      type: selectedGameType.toUpperCase(),
    );

    setState(() {
      if (existingBidIndex != -1) {
        // Update the existing bid entry
        bidEntries[existingBidIndex] = newBid;
        _showMessage(
          'Bid for Digit $number (${selectedGameType.toUpperCase()}) updated to $amount points.',
          isError: false,
        );
      } else {
        // Add a new bid entry
        bidEntries.add(newBid);
        _showMessage('Added bid for Digit: $number, Amount: $amount');
      }
    });
  }

  int _getTotalPoints() {
    return bidEntries
        .map((e) => int.tryParse(e.points) ?? 0)
        .fold(0, (a, b) => a + b);
  }

  // --- Confirmation Dialog and Final Bid Submission (Modified) ---
  void _showConfirmationDialog() {
    _clearMessage();
    if (bidEntries.isEmpty) {
      _showMessage(
        'Please add at least one bid before submitting.',
        isError: true,
      );
      return;
    }

    final int totalPoints = _getTotalPoints();
    final int currentWalletBalance =
        _walletBalance; // _walletBalance is already int

    if (currentWalletBalance < totalPoints) {
      _showMessage(
        'Insufficient wallet balance to place these bids.',
        isError: true,
      );
      return;
    }

    final String formattedDate = DateFormat(
      'dd MMM yyyy, hh:mm a',
    ).format(DateTime.now());

    // Transform bidEntries into a List of Maps for the dialog.
    // This will include all bids, regardless of their type.
    List<Map<String, String>> bidsForDialog = bidEntries.map((bid) {
      return {
        "digit": bid.digit,
        "points": bid.points,
        "type": bid.type, // Use the stored type
        "pana": "", // pana should be empty for single digits
      };
    }).toList();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return BidConfirmationDialog(
          gameTitle: "${widget.gameName} - ${widget.gameType}",
          gameDate: formattedDate,
          bids: bidsForDialog, // Pass the entire list of bids
          totalBids: bidEntries.length,
          totalBidsAmount: totalPoints,
          walletBalanceBeforeDeduction: currentWalletBalance,
          walletBalanceAfterDeduction: (currentWalletBalance - totalPoints)
              .toString(),
          gameId: widget.gameId.toString(),
          gameType: widget.gameType,
          onConfirm: () {
            // Dismiss the confirmation dialog before showing success/failure
            _placeFinalBids(); // Call the bid placement method
            // Navigator.pop(dialogContext);
          },
        );
      },
    );
  }

  Future<bool> _placeFinalBids() async {
    setState(() {
      _isApiCalling = true; // Set loading state to true
    });

    // Create the Map<String, String> in the correct format: digit -> points
    // The key should be the digit, and the value should be the points.
    final Map<String, String> bidsForService = {};
    for (var bid in bidEntries) {
      // The key is the digit, the value is the points.
      // The type is not part of the key here.
      bidsForService[bid.digit] = bid.points;
    }

    // Call the bid service with the formatted map and the selectedGameType.
    final result = await _bidService.placeFinalBids(
      gameName: widget.gameName,
      accessToken: _accessToken,
      registerId: _registerId,
      deviceId: _deviceId,
      deviceName: _deviceName,
      accountStatus: _accountStatus,
      bidAmounts: bidsForService, // Passing the corrected map of bids
      gameId: widget.gameId,
      gameType: widget.gameType,
      totalBidAmount: _getTotalPoints(),
      selectedGameType:
          selectedGameType, // This parameter is handled correctly by your BidService
    );

    if (!mounted) {
      setState(() {
        _isApiCalling = false;
      });
      return false;
    }

    // Ensure context is still valid before showing final dialog
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!context.mounted) return;

      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => result['status']
            ? const BidSuccessDialog()
            : BidFailureDialog(errorMessage: result['msg']),
      );

      if (result['status'] && context.mounted) {
        final int newBalance = _walletBalance - _getTotalPoints();
        setState(() {
          _walletBalance = newBalance;
          bidEntries.clear(); // Clear bids on successful submission
          pointsController.clear(); // Clear points text field
        });
        await _bidService.updateWalletBalance(newBalance);
        _showMessage('Bids submitted successfully!'); // Show success message
      }
    });

    // Update loading state after the dialog is shown
    setState(() {
      _isApiCalling = false;
    });

    return result['status'] == true;
  }

  Widget _buildDropdown(bool selectionStatus) {
    final List<String> gameTypesOptions = ['OPEN', 'CLOSE'];

    final List<String> filteredOptions = selectionStatus
        ? gameTypesOptions
        : gameTypesOptions
              .where((opt) => opt.toLowerCase() == 'close')
              .toList();

    if (!filteredOptions.contains(selectedGameType.toUpperCase())) {
      selectedGameType = filteredOptions.first;
    }

    return SizedBox(
      width: 150,
      height: 35,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black54),
          borderRadius: BorderRadius.circular(30),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            isExpanded: true,
            value: selectedGameType.toUpperCase(),
            icon: const Icon(Icons.keyboard_arrow_down),
            onChanged:
                _isApiCalling // Disable dropdown when API is calling
                ? null
                : (String? newValue) {
                    setState(() {
                      selectedGameType = newValue!;
                      _clearMessage();
                    });
                  },
            items: filteredOptions.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value, style: GoogleFonts.poppins(fontSize: 14)),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField() {
    return SizedBox(
      height: 40,
      width: 150,
      child: TextFormField(
        controller: pointsController,
        cursorColor: Colors.orange,
        keyboardType: TextInputType.number,
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
          LengthLimitingTextInputFormatter(4),
        ],
        style: GoogleFonts.poppins(fontSize: 14),
        decoration: InputDecoration(
          hintText: 'Enter Amount',
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 0,
          ),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.orange, width: 1),
          ),
        ),
        onTap: () {
          setState(() {
            textFieldBorderColor = Colors.orange;
            _clearMessage();
          });
        },
        enabled: !_isApiCalling, // Disable text field during API call
      ),
    );
  }

  Widget _inputRow(String label, Widget field) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          field,
        ],
      ),
    );
  }

  Widget _buildNumberPad() {
    final numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

    return Column(
      children: [
        // 🔥 3x3 Grid for 1–9
        GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 2, // Reduced spacing
            mainAxisSpacing: 2, // Reduced spacing
            childAspectRatio: 2,
          ),
          itemCount: numbers.length,
          itemBuilder: (context, index) {
            final number = numbers[index];

            final bid = bidEntries.firstWhereOrNull(
              (element) =>
                  element.digit == number &&
                  element.type == selectedGameType.toUpperCase(),
            );

            return _buildNumberButton(number, bid);
          },
        ),

        const SizedBox(height: 2), // Reduced spacing
        // 🔥 0 — Centered
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 110, // Slightly reduced size
              height: 60, // Slightly reduced size
              child: _buildNumberButton(
                "0",
                bidEntries.firstWhereOrNull(
                  (element) =>
                      element.digit == "0" &&
                      element.type == selectedGameType.toUpperCase(),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildNumberButton(String number, dynamic bid) {
    return GestureDetector(
      onTap: _isApiCalling ? null : () => onNumberPressed(number),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            //  width: 70,
            height: 50, // Reduced height
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: _isApiCalling ? Colors.grey : Color(0xffE8910C),
              borderRadius: BorderRadius.circular(
                8,
              ), // Slightly reduced border radius
              boxShadow: _isApiCalling
                  ? []
                  : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        spreadRadius: 1,
                        blurRadius: 2, // Reduced blur radius
                        offset: const Offset(0, 1), // Reduced shadow offset
                      ),
                    ],
            ),
            child: Text(
              number,
              style: GoogleFonts.poppins(
                fontSize: 20, // Slightly reduced font size
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),

          if (bid != null)
            Positioned(
              top: 2, // Moved closer to top
              right: 4, // Moved closer to right
              child: Text(
                bid.points,
                style: GoogleFonts.poppins(
                  fontSize: 11, // Reduced font size
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    int totalAmount = _getTotalPoints();

    return Scaffold(
      // // Apply the same gradient background as MyBidsPage.dart
      // backgroundColor: Colors.transparent,
      // appBar: AppBar(
      //   backgroundColor: Colors.transparent,
      //   elevation: 0,
      //   leading: IconButton(
      //     onPressed: () => Navigator.pop(context),
      //     icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
      //   ),
      //   title: Text(
      //     widget.title,
      //     style: GoogleFonts.poppins(
      //       fontWeight: FontWeight.bold,
      //       fontSize: 16,
      //       color: Colors.black,
      //     ),
      //   ),
      //   actions: [
      //     Padding(
      //       padding: const EdgeInsets.only(right: 16),
      //       child: Row(
      //         children: [
      //           GestureDetector(
      //             onTap: () {
      //               // Handle wallet tap if needed
      //               _walletBalance = int.parse(
      //                 userController.walletBalance.value,
      //               );
      //             },
      //             child: SizedBox(
      //               height: 42,
      //               child: Row(
      //                 mainAxisAlignment: MainAxisAlignment.end,
      //                 children: [
      //                   Image.asset(
      //                     "assets/images/ic_wallet.png",
      //                     width: 22,
      //                     height: 22,
      //                     color: Colors.black,
      //                   ),
      //                   const SizedBox(width: 4),
      //                   Text(
      //                     "₹${_walletBalance}", // Use _walletBalance
      //                     style: GoogleFonts.poppins(
      //                       color: Colors.black,
      //                       fontSize: 16, // Consistent font size
      //                     ),
      //                   ),
      //                 ],
      //               ),
      //             ),
      //           ),
      //         ],
      //       ),
      //     ),
      //   ],
      // ),
      body: Container(
        width: double.infinity,
        height: double.infinity,

        /// 🔥 FULL GRADIENT BACKGROUND (Copied from MyBidsPage.dart)
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFE8D1), Color(0xFFEFF8F0)],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              SizedBox(height: 12),
              // ⭐ OUTER ROUNDED CONTAINER WITH TOP ROUNDED CORNERS ONLY ⭐
              Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 0,
                  ), // Remove horizontal margin
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30), // Match MyBidsPage radius
                      topRight: Radius.circular(30), // Match MyBidsPage radius
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      const SizedBox(height: 24),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.grey, // grey border color
                                    width: 1, // border thickness
                                  ),
                                ),

                                child: const Icon(
                                  Icons.arrow_back,
                                  color: Colors.black,
                                  size: 20,
                                ),
                              ),
                            ),
                            Text(
                              widget.title,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1, // only one line allowed
                              overflow: TextOverflow.ellipsis, // show ...
                            ),

                            // 🔥 WALLET CAPSULE (dark blue)
                            Obx(
                              () => userController.accountStatus.value
                                  ? Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 8,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0B1223),
                                        borderRadius: BorderRadius.circular(40),
                                      ),
                                      child: Row(
                                        children: [
                                          Image.asset(
                                            "assets/images/ic_wallet.png",
                                            width: 20,
                                            height: 20,
                                            color: Colors.white,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "₹${userController.walletBalance.value}",
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            _inputRow(
                              "Select Game Type:",
                              _buildDropdown(widget.selectionStatus),
                            ),
                            _inputRow("Enter Points:", _buildTextField()),
                            const SizedBox(height: 30),
                            _buildNumberPad(), // Number pad internally handles _isApiCalling visual state
                            const SizedBox(height: 20),
                            if (bidEntries
                                .isNotEmpty) // Only show headers if bids exist
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 0.0,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 2,
                                      child: Text(
                                        'Digit',
                                        style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 3,
                                      child: Text(
                                        'Points',
                                        style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Text(
                                        'Type',
                                        style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 48,
                                    ), // Space for delete icon
                                  ],
                                ),
                              ),
                            Expanded(
                              child: bidEntries.isEmpty
                                  ? Center(
                                      child: Text(
                                        'No bids placed yet. Click a number to add a bid!',
                                        style: GoogleFonts.poppins(
                                          color: Colors.grey,
                                        ),
                                      ),
                                    )
                                  : ListView.builder(
                                      itemCount: bidEntries.length,
                                      itemBuilder: (context, index) {
                                        final bid = bidEntries[index];
                                        return _buildBidEntryItem(
                                          bid.digit,
                                          bid.points,
                                          bid.type,
                                        );
                                      },
                                    ),
                            ),
                          ],
                        ),
                      ),
                      // AnimatedMessageBar positioned at the top
                      if (_messageToShow != null)
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          child: AnimatedMessageBar(
                            key: _messageBarKey,
                            message: _messageToShow!,
                            isError: _isErrorForMessage,
                            onDismissed: _clearMessage,
                          ),
                        ),
                      // Bottom total bar (always visible, disabled when no bids)
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                spreadRadius: 2,
                                blurRadius: 5,
                                offset: const Offset(0, -3),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Bids", // Changed to "Bids" for clarity
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  Text(
                                    "${bidEntries.length}",
                                    style: GoogleFonts.poppins(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Points", // Changed to "Points" for clarity
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  Text(
                                    "$totalAmount",
                                    style: GoogleFonts.poppins(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              ElevatedButton(
                                onPressed: (_isApiCalling || bidEntries.isEmpty)
                                    ? null // Disable button while API is calling OR if no bids
                                    : _showConfirmationDialog,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      (_isApiCalling || bidEntries.isEmpty)
                                      ? Colors.grey
                                      : Colors.orange, // Grey out when disabled
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 24, // Consistent padding
                                    vertical: 12,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                      8,
                                    ), // Consistent border radius
                                  ),
                                  elevation: 3, // Consistent elevation
                                ),
                                child: _isApiCalling
                                    ? const SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                                Colors.white,
                                              ),
                                        ),
                                      )
                                    : Text(
                                        "SUBMIT", // Consistent text
                                        style: GoogleFonts.poppins(
                                          color: Colors.white,
                                          fontSize: 16,
                                        ),
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBidEntryItem(String digit, String points, String type) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Text(
                digit,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Text(
                points,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                type.toUpperCase(), // Display the stored type in uppercase
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: type.toLowerCase() == 'open'
                      ? Colors.blue[700] // Differentiate open/close visually
                      : Colors.green[700],
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.orange),
              onPressed: _isApiCalling
                  ? null // Disable delete button while API is calling
                  : () {
                      setState(() {
                        // Find the specific bid to remove
                        final indexToRemove = bidEntries.indexWhere(
                          (bid) => bid.digit == digit && bid.type == type,
                        );
                        if (indexToRemove != -1) {
                          final removedBid = bidEntries.removeAt(indexToRemove);
                          _showMessage(
                            'Removed bid for Digit: ${removedBid.digit}, Amount: ${removedBid.points}.',
                          );
                        }
                      });
                    },
            ),
          ],
        ),
      ),
    );
  }
}

// Add this extension for convenience to find an element or return null
extension IterableExtension<E> on Iterable<E> {
  E? firstWhereOrNull(bool Function(E element) test) {
    for (var element in this) {
      if (test(element)) {
        return element;
      }
    }
    return null;
  }
}
