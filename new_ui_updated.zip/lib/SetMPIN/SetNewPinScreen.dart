import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:new_sara/HomeScreen/HomeScreen.dart';

import '../Helper/Toast.dart';
import '../ulits/ColorsR.dart';
import '../ulits/Constents.dart';

class SetNewPinScreen extends StatefulWidget {
  final String mobile;
  const SetNewPinScreen({super.key, required this.mobile});

  @override
  State<SetNewPinScreen> createState() => _SetNewPinScreenState();
}

class _SetNewPinScreenState extends State<SetNewPinScreen> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController pinController = TextEditingController();
  final storage = GetStorage();

  late final String fcmToken;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fcmToken = storage.read("fcmToken") ?? "";
  }

  @override
  void dispose() {
    passwordController.dispose();
    pinController.dispose();
    super.dispose();
  }

  Future<void> setNewPin() async {
    final password = passwordController.text.trim();
    final newPin = pinController.text.trim();

    if (password.isEmpty) {
      popToast("Please enter your password", 4, Colors.white, ColorsR.appColorRed);
      return;
    }

    if (newPin.isEmpty || newPin.length != 4) {
      popToast("Please enter a valid 4-digit PIN", 4, Colors.white, ColorsR.appColorRed);
      return;
    }

    setState(() => isLoading = true);

    final body = {
      "mobileNo": int.tryParse(widget.mobile),
      "password": password,
      "security_pin": int.tryParse(newPin),
      "fcmToken": fcmToken,
    };

    try {
      final response = await http.post(
        Uri.parse("${Constant.apiEndpoint}reset-mpin"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      );

      final json = jsonDecode(response.body);
      final status = json["status"] ?? false;
      final msg = json["msg"] ?? "Something went wrong";

      if (status == true) {
        final info = json["info"];
        storage.write("user_mpin", newPin);
        storage.write("registerId", info["registerId"]);
        storage.write("accessToken", info["accessToken"]);

        popToast(msg, 2, Colors.white, Colors.green);

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const HomeScreen()),
              (route) => false,
        );
      } else {
        popToast(msg, 4, Colors.white, ColorsR.appColorRed);
      }
    } catch (e) {
      popToast("Error: $e", 4, Colors.white, ColorsR.appColorRed);
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: Container(
        width: double.infinity,
        height: double.infinity,

        /// SAME THEME GRADIENT
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFE7D1),
              Color(0xFFEFF8F0)
            ],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),

        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 30),

              /// ⭐ TITLE
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  children: [
                  //  Container(width: 10, height: 45, color: Colors.orange),
                    const SizedBox(width: 10),
                    // Text(
                    //   "SET NEW\nPIN",
                    //   style: GoogleFonts.poppins(
                    //     fontSize: 26,
                    //     fontWeight: FontWeight.w700,
                    //     color: Colors.black,
                    //   ),
                    // )
                  ],
                ),
              ),

              const SizedBox(height: 20),

              /// ⭐ WHITE ROUNDED CONTAINER
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.only(left: 24,right: 24,top: 13,bottom: 30),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                  ),

                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            // BACK BUTTON - CIRCULAR
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.grey.shade200,
                                ),
                                child: const Icon(Icons.arrow_back, size: 18, color: Colors.black),
                              ),
                            ),

                            const SizedBox(width: 12),

                            const Text(
                              "Change New MPIN",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),



                        const SizedBox(height: 10),

                        _buildFieldTitle("Enter Password"),
                        const SizedBox(height: 8),

                        _buildInputField(
                          controller: passwordController,
                          hint: "Enter your password",
                          isNumber: false,
                          isPassword: true,
                          icon: Icons.lock,
                        ),

                        const SizedBox(height: 25),

                        _buildFieldTitle("Enter New mPin"),
                        const SizedBox(height: 8),

                        _buildInputField(
                          controller: pinController,
                          hint: "Enter 4-digit PIN",
                          isNumber: true,
                          maxLength: 4,
                          isPassword: true,
                          icon: Icons.password,
                        ),

                        const SizedBox(height: 45),

                        /// ⭐ BUTTON
                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : setNewPin,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: isLoading
                                ? const CircularProgressIndicator(color: Colors.white)
                                : const Text(
                              "SET PIN",
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// ---------------------------
  /// COMMON FIELD TITLE
  /// ---------------------------
  Widget _buildFieldTitle(String text) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: Colors.black87,
        ),
      ),
    );
  }

  /// ---------------------------
  /// COMMON INPUT FIELD (THEME)
  /// ---------------------------
  Widget _buildInputField({
    required TextEditingController controller,
    required String hint,
    required bool isNumber,
    bool isPassword = false,
    int maxLength = 50,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(40),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 3),
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
              color: Colors.orange,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: isPassword,
              maxLength: maxLength,
              keyboardType:
              isNumber ? TextInputType.number : TextInputType.text,
              cursorColor: Colors.orange,
              decoration: InputDecoration(
                hintText: hint,
                counterText: "",
                border: InputBorder.none,
              ),
            ),
          )
        ],
      ),
    );
  }
}
