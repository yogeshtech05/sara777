import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:new_sara/login/VerifyMobileScreen.dart';

import '../../../ulits/ColorsR.dart';
import '../../Helper/Toast.dart';

class SetPinScreen extends StatefulWidget {
  const SetPinScreen({super.key});

  @override
  State<SetPinScreen> createState() => _SetPinScreenState();
}

class _SetPinScreenState extends State<SetPinScreen> {
  final TextEditingController mpinController = TextEditingController();
  final storage = GetStorage();

  bool isLoading = false;

  void _onSetPinPressed() async {
    final pin = mpinController.text.trim();

    if (pin.isEmpty || pin.length != 4 || !RegExp(r'^\d{4}$').hasMatch(pin)) {
      popToast("Please enter a valid 4-digit PIN", 4,
          Colors.white, ColorsR.appColorRed);
      return;
    }

    final mobile = storage.read('mobile');
    if (mobile == null || mobile.toString().isEmpty) {
      popToast("Mobile number not found", 4,
          Colors.white, ColorsR.appColorRed);
      return;
    }

    setState(() => isLoading = true);

    try {
      storage.write('user_mpin', pin);

      Future.delayed(const Duration(milliseconds: 500), () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const VerifyMobileScreen()),
        );
      });
    } catch (e) {
      popToast("Something went wrong: $e", 4,
          Colors.white, ColorsR.appColorRed);
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    mpinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: Container(
        width: double.infinity,
        height: double.infinity,

        /// SAME GRADIENT THEME
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFE7D1),
              Color(0xFFEFF8F0),
            ],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),

        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 30),

              /// ⭐ TITLE
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  children: [
                    Container(width: 10, height: 45, color: Colors.orange),
                    const SizedBox(width: 10),
                    Text(
                      "SET YOUR\nPIN",
                      style: GoogleFonts.poppins(
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              /// ⭐ MAIN WHITE CARD
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 30),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                  ),

                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        // const SizedBox(height: 20),
                        //
                        // Image.asset(
                        //   'assets/images/set_mpin_avatar.png',
                        //   height: 180,
                        // ),

                        const SizedBox(height: 30),

                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Enter New mPin",
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                          ),
                        ),

                        const SizedBox(height: 15),

                        /// ⭐ PIN INPUT FIELD (Same theme)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 18),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(40),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 6,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: const BoxDecoration(
                                  color: Colors.orange,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.password,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: TextField(
                                  controller: mpinController,
                                  maxLength: 4,
                                  keyboardType: TextInputType.number,
                                  obscureText: true,
                                  cursorColor: Colors.orange,
                                  decoration: const InputDecoration(
                                    hintText: "Enter 4-digit mPin",
                                    counterText: "",
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 40),

                        /// ⭐ BUTTON
                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : _onSetPinPressed,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: isLoading
                                ? const CircularProgressIndicator(
                                color: Colors.white)
                                : const Text(
                              "SET PIN",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
