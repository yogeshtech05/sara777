import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:new_sara/Bids/BidHistory/BidHistoryScreen.dart';
import 'package:new_sara/Bids/KingJackpotBidHis/KingJackpotHistoryScreen.dart';
import 'package:new_sara/Bids/KingJackpotResultHis/KingJackpotResultScreen.dart';
import 'package:new_sara/Bids/KingStartlineBidHis/KingStarlineBidHistoryScreen.dart';
import 'package:new_sara/game/GameResults/GameResultScreen.dart';
import '../Helper/UserController.dart';
import 'KingStarlineResultHis/KingStarlineResultHis.dart';
import '../HomeScreen/HomeScreen.dart';

class BidScreen extends StatefulWidget {
  @override
  State<BidScreen> createState() => _BidScreenState();
}

class _BidScreenState extends State<BidScreen> {
  final UserController userController = Get.put(UserController());
  final List<_BidOption> bidOptions = [
    _BidOption(
      "BID HISTORY",
      "You can view your market bid history",
      Icons.trending_up,
    ),

    _BidOption(
      "King Starline Bid History",
      "You can view your starline bid history",
      Icons.account_balance,
    ),

    _BidOption(
      "KING JACKPOT BID HISTORY",
      "You can view your jackpot bid history",
      Icons.attach_money,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Apply the same gradient background as FundPage.dart
      backgroundColor: Colors.transparent,

      body: Container(
        width: double.infinity,
        height: double.infinity,

        /// 🔥 FULL GRADIENT BACKGROUND (Copied from FundPage.dart)
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFE8D1), Color(0xFFEFF8F0)],
            begin: Alignment.topLeft,
            end: Alignment.topRight,
          ),
        ),

        child: SafeArea(
          child: Column(
            children: [
              SizedBox(height: 12),

              // ⭐ OUTER ROUNDED CONTAINER WITH TOP ROUNDED CORNERS ONLY ⭐
              Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 0,
                  ), // Remove horizontal margin
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30), // Match FundPage radius
                      topRight: Radius.circular(30), // Match FundPage radius
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: () {
                                // Navigate to HomeScreen instead of popping
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(builder: (context) => HomeScreen()),
                                  (route) => false,
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.grey, // grey border color
                                    width: 1, // border thickness
                                  ),
                                ),

                                child: const Icon(
                                  Icons.arrow_back,
                                  color: Colors.black,
                                  size: 20,
                                ),
                              ),
                            ),
                            Text(
                              'History',
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1, // only one line allowed
                              overflow: TextOverflow.ellipsis, // show ...
                            ),

                            // 🔥 WALLET CAPSULE (dark blue)
                            Obx(
                              () => userController.accountStatus.value
                                  ? Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 8,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0B1223),
                                        borderRadius: BorderRadius.circular(40),
                                      ),
                                      child: Row(
                                        children: [
                                          Image.asset(
                                            "assets/images/ic_wallet.png",
                                            width: 20,
                                            height: 20,
                                            color: Colors.white,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "₹${userController.walletBalance.value}",
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          padding: EdgeInsets.only(top: 10),
                          itemCount: bidOptions.length,
                          itemBuilder: (context, index) {
                            final item = bidOptions[index];

                            return InkWell(
                              onTap: () {
                                if (item.title == "BID HISTORY") {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => BidHistoryPage(),
                                    ),
                                  );
                                }

                                if (item.title == "King Starline Bid History") {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          KingStarlineBidHistoryScreen(),
                                    ),
                                  );
                                }

                                if (item.title == "KING JACKPOT BID HISTORY") {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          KingJackpotHistoryScreen(),
                                    ),
                                  );
                                }

                                if (item.title ==
                                    "King Starline Result History") {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          KingStarlineResultScreen(),
                                    ),
                                  );
                                }

                                if (item.title ==
                                    "KING JACKPOT RESULT HISTORY") {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => KingJackpotResultScreen(),
                                    ),
                                  );
                                }

                                if (item.title == "Game Results") {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => GameResultScreen(),
                                    ),
                                  );
                                }
                              },

                              child: Container(
                                margin: EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                                padding: EdgeInsets.symmetric(
                                  vertical: 10,
                                  horizontal: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: Color(0xffFCFCFC),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: Colors.grey.shade300,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xffFE8545),
                                      ),
                                      child: Icon(
                                        item.icon,
                                        size: 26,
                                        color: Colors.white,
                                      ),
                                    ),

                                    SizedBox(width: 18),

                                    Expanded(
                                      child: Text(
                                        item.title,
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),

                                    Icon(
                                      Icons.arrow_forward_ios,
                                      size: 18,
                                      color: Colors.orange,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BidOption {
  final String title;
  final String subtitle;
  final IconData icon;

  _BidOption(this.title, this.subtitle, this.icon);
}
