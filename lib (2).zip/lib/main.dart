import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get_storage/get_storage.dart';

import 'Splash.dart';

// ---------- Background Handler (Separate Isolate) ----------
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  await Firebase.initializeApp();

  // Use a NEW plugin instance in BG isolate
  final bgPlugin = FlutterLocalNotificationsPlugin();
// ---------- Print FCM Token (Release + Debug Both) ----------
  final fcmToken = await FirebaseMessaging.instance.getToken();
  print("🔥 FCM TOKEN (Release/Debug): $fcmToken");
  const initSettings = InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
  );
  await bgPlugin.initialize(initSettings);

  const channel = AndroidNotificationChannel(
    'default_channel',
    'Default Channel',
    description: 'Used for general notifications.',
    importance: Importance.high,
  );

  final bgAndroid = bgPlugin
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  await bgAndroid?.createNotificationChannel(channel);

  final title = message.notification?.title ?? message.data['title'];
  final body = message.notification?.body ?? message.data['body'];

  const details = NotificationDetails(
    android: AndroidNotificationDetails(
      'default_channel',
      'Default Channel',
      channelDescription: 'Used for general notifications.',
      importance: Importance.max,
      priority: Priority.high,
      icon: '@drawable/ic_launcher', // <-- must exist
      playSound: true,
    ),
  );

  await bgPlugin.show(message.hashCode, title, body, details);
}

// ---------- Local Notifications Setup ----------
Future<void> _bootstrapLocalNotifications() async {
  final plugin = FlutterLocalNotificationsPlugin();

  const initSettings = InitializationSettings(
    android: AndroidInitializationSettings('@drawable/ic_launcher'),
  );
  await plugin.initialize(initSettings);

  const channel = AndroidNotificationChannel(
    'default_channel',
    'Default Channel',
    description: 'Used for general notifications.',
    importance: Importance.high,
  );

  final android = plugin
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  await android?.createNotificationChannel(channel);
  await android?.requestNotificationsPermission(); // Android 13+
}

// ---------- Main Function ----------
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // MUST be registered BEFORE runApp
  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  await _bootstrapLocalNotifications();

  runApp(const MyApp());
}

// ---------- MyApp Widget ----------
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sara777',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // The home screen is now the SplashScreen, which handles all initialization
      home: const SplashScreen(),
    );
  }
}
